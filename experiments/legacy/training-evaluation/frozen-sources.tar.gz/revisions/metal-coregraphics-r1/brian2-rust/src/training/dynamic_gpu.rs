//! v5 GPU action ABI. Ordered execution and VJP run on device; Rust commits
//! the optimizer and checks the complete host/device allocation budget.
use super::*;

#[cfg(not(unix))]
pub(super) fn execute(_: &Plan, _: State, _: &[Vec<Vec<f64>>], _: &[usize], _: &[Vec<f64>],
    _: usize, _: &str, _: Option<&mpi::Context>, _: u64, _: u64, _: bool) -> Result<Output> {
    Err("dynamic GPU training requires a Unix host".into())
}

#[cfg(unix)]
pub(super) fn execute(plan: &Plan, mut state: State, inputs: &[Vec<Vec<f64>>], labels: &[usize],
    initial: &[Vec<f64>], bytes: usize, operation: &str, mpi: Option<&mpi::Context>,
    start_tick: u64, sequence: u64, default_initial: bool) -> Result<Output> {
    ensure(inputs.iter().flatten().flatten().all(|&x| x == 0.0 || x == 1.0), "dynamic event inputs must be binary spikes")?;
    let spec = plan.dynamic.as_ref().unwrap();
    let (_, n) = plan.validate()?;
    let b = inputs.len(); let t = inputs[0].len(); let i = plan.sizes[0];
    let width = spec.initial.len(); let classes = *plan.sizes.last().unwrap();
    let edges = state.weights.iter().map(Vec::len).sum::<usize>();
    let reads = spec.actions.iter().map(|a| a.reads.len()).sum::<usize>();
    let address_words = spec.actions.iter().filter_map(|a| a.indirect.as_ref()).map(|v| {
        v.reads.values().map(|r| 2 + r.tables.len()*2 + r.tables.iter().map(Vec::len).sum::<usize>()).sum::<usize>()
        + v.writes.values().map(|r| 3 + r.tables.len()*2 + r.tables.iter().map(Vec::len).sum::<usize>()).sum::<usize>()
    }).sum::<usize>() + spec.actions.iter().filter(|a| a.indirect.is_some()).map(|a| 2+a.reads.len()+a.writes.len()).sum::<usize>();
    let tape_width = reads + spec.actions.iter().filter(|a| a.indirect.is_some()).map(|a| a.reads.len()+2*a.writes.len()).sum::<usize>();
    let writes = spec.actions.iter().map(|a| a.writes.len()).sum::<usize>();
    let nodes = spec.program_sets.iter().flatten().map(Vec::len).sum::<usize>();
    let programs = spec.program_sets.iter().map(Vec::len).sum::<usize>();
    let noise_width = spec.actions.iter().map(|a| a.noise_streams).sum::<usize>();
    let clocks = spec.clocks.as_ref().map_or(0, |c| c.dts.len());
    // u128 admission arithmetic precedes all staging/tape allocations. This
    // includes the simultaneous Rust and device copies and per-sample scratch.
    let map_entries = spec.parameter_maps.iter().map(Vec::len).sum::<usize>();
    let timed_nodes = spec.program_sets.iter().flatten().flatten().filter(|node| matches!(node, equation::Node::TimedParameter { .. })).count();
    let elapsed_nodes = spec.program_sets.iter().flatten().flatten().filter(|node| matches!(node, equation::Node::ElapsedCompare { .. })).count();
    let precise_time = elapsed_nodes != 0 || spec.program_sets.iter().flatten().flatten().any(|node| matches!(node, equation::Node::TimeWord { .. }));
    let meta_count = 37u128 + address_words as u128 + 4 * (timed_nodes + elapsed_nodes) as u128 + if precise_time { t as u128 } else { 0 } + 16 * spec.actions.len() as u128 + (reads + writes + 4 * nodes + 3 * programs + 4 * width + 2 * n + map_entries) as u128;
    let param_count = (3 + n + edges + nodes) as u128 + t as u128 * (1 + clocks) as u128
        + b as u128 * t as u128 * noise_width as u128;
    let floats = b as u128 * t as u128 * (i + tape_width + n) as u128 + edges as u128
        + b as u128 * (3 * width + edges + classes + 1) as u128;
    let gpu_bytes = 2 * (meta_count * 8 + param_count * 4 + floats * 4 + b as u128 * 8)
        + b as u128 * n as u128 * 4 + b as u128 * 4096
        + t as u128 * clocks as u128 * 8
        + spec.parameter_maps.len() as u128 * 8
        + if mpi.is_some() { b as u128 * 130 * 4 + 130 * 12 } else { 0 };
    ensure(gpu_bytes + bytes as u128 <= plan.max_tape_bytes as u128, "native dynamic GPU tape budget exceeded")?;
    let gpu_bytes = gpu_bytes as usize;
    fn f32_value(x: f64) -> Result<f32> {
        let y = x as f32; ensure(y.is_finite(), "dynamic GPU value cannot be represented in float32")?; Ok(y)
    }
    fn cast(values: impl Iterator<Item=f64>, count: usize) -> Result<Vec<f32>> {
        let mut out = Vec::with_capacity(count);
        for value in values { out.push(f32_value(value)?); }
        ensure(out.len() == count, "dynamic GPU staging shape mismatch")?;
        Ok(out)
    }
    let mut parameter_offsets = Vec::with_capacity(state.weights.len()+1); parameter_offsets.push(0usize);
    for row in &state.weights { parameter_offsets.push(parameter_offsets.last().unwrap() + row.len()); }
    // Reserve admitted sizes once: geometric Vec growth could otherwise make
    // the large noise/input staging capacity exceed the element-count budget.
    let mut meta = Vec::with_capacity(meta_count as usize); meta.resize(32,0u64);
    let mut params = Vec::with_capacity(param_count as usize);
    params.extend(cast([plan.surrogate.slope, plan.surrogate.scale, plan.logit_scale].into_iter(),3)?);
    meta[..13].copy_from_slice(&[b as u64,t as u64,i as u64,n as u64,width as u64,edges as u64,classes as u64,
        spec.actions.len() as u64,tape_width as u64,(operation != "evaluate") as u64,plan.tbptt_window.unwrap_or(0) as u64,0,0]);
    meta[13] = meta.len() as u64; meta.resize(meta.len() + 16 * spec.actions.len(), 0);
    let mut map_offsets = Vec::with_capacity(spec.parameter_maps.len());
    for row in &spec.parameter_maps { map_offsets.push(meta.len() as u64); meta.extend(row.iter().map(|&i| i as u64)); }
    let mut headers = Vec::with_capacity(spec.program_sets.len());
    for set in &spec.program_sets {
        let h = meta.len(); headers.push(h); meta.resize(h + 3 * set.len(), 0);
        for (s, program) in set.iter().enumerate() {
            let descriptors = meta.len();
            for node in program {
                if let equation::Node::TimedParameter { bank, rows, columns, k, epsilon, .. } = *node {
                    ensure(f32_value(epsilon)? > 0.0, "TimedArray time resolution underflows float32")?;
                    meta.extend_from_slice(&[parameter_offsets[bank] as u64, rows as u64, columns as u64, k]);
                } else if let equation::Node::ElapsedCompare { right, kind, constant, .. } = *node {
                    meta.extend_from_slice(&[right as u64,kind as u64,constant.is_some() as u64,constant.unwrap_or(0.0).to_bits()]);
                }
            }
            let mut timed_offset = descriptors;
            meta[h+3*s] = program.len() as u64; meta[h+3*s+1] = meta.len() as u64; meta[h+3*s+2] = params.len() as u64;
            for node in program {
                let (mut row, value) = equation::gpu_node(node, &parameter_offsets);
                if row[0] == 24 || row[0] == 37 { row[1] = map_offsets[row[1] as usize]; }
                if row[0] == 25 || row[0] == 51 { row[3] = timed_offset as u64; timed_offset += 4; }
                meta.extend_from_slice(&row); params.push(f32_value(value)?);
            }
        }
    }
    fn append_tables(meta: &mut Vec<u64>, tables: &[Vec<usize>]) {
        let at=meta.len(); meta.resize(at+tables.len()*2,0);
        for (d,row) in tables.iter().enumerate() {
            meta[at+2*d]=row.len() as u64; meta[at+2*d+1]=meta.len() as u64;
            meta.extend(row.iter().map(|&k|k as u64));
        }
    }
    let mut context = 0usize; let mut noise_offset = 0usize;
    for (a, action) in spec.actions.iter().enumerate() {
        let h = meta[13] as usize + 16 * a;
        meta[h] = context as u64; context += action.reads.len();
        meta[h+1] = action.reads.len() as u64; meta[h+2] = meta.len() as u64;
        meta.extend(action.reads.iter().map(|&k| k as u64));
        meta[h+3] = action.writes.len() as u64; meta[h+4] = meta.len() as u64;
        meta.extend(action.writes.iter().map(|&k| k as u64));
        meta[h+5] = action.program_set.map_or(0, |p| headers[p]) as u64;
        meta[h+6] = action.threshold.map_or(0, |k| k+1) as u64;
        if let Some(gate) = &action.trigger {
            meta[h+7] = if gate.state {3} else if gate.external {1} else {2};
            meta[h+8] = if gate.state { action.reads.iter().position(|&k| k == gate.index).unwrap() } else {gate.index} as u64;
        }
        meta[h+9] = action.detach_trigger as u64;
        meta[h+10] = action.mask.map_or(1, |[bank,index]| plan.masks[bank][index] as u64);
        meta[h+11] = action.parameter_index as u64;
        meta[h+12] = noise_offset as u64; noise_offset += action.noise_streams;
        meta[h+13] = action.owner as u64;
        meta[h+14] = if action.threshold_predicate { 3 } else if action.threshold_margin { if action.threshold_inclusive { 2 } else { 1 } } else { 0 };
        if let Some(access)=&action.indirect {
            let desc=meta.len();meta[h+15]=desc as u64;meta.resize(desc+2,0);
            let read_map=meta.len();meta[desc]=read_map as u64;meta.resize(read_map+action.reads.len(),0);
            let write_map=meta.len();meta[desc+1]=write_map as u64;meta.resize(write_map+action.writes.len(),0);
            for (&slot,r) in &access.reads {
                meta[read_map+slot]=meta.len() as u64;
                meta.extend_from_slice(&[r.index as u64,r.tables.len() as u64]);append_tables(&mut meta,&r.tables);
            }
            for (&slot,r) in &access.writes {
                meta[write_map+slot]=meta.len() as u64;
                let (kind,index)=match r.index {indirect::Index::Read{slot}=>(0,slot),indirect::Index::Output{slot}=>(1,slot)};
                meta.extend_from_slice(&[kind,index as u64,r.tables.len() as u64]);append_tables(&mut meta,&r.tables);
            }
            context+=action.reads.len()+2*action.writes.len();
        }
    }
    meta[15] = meta.len() as u64; meta.extend(spec.voltage.iter().map(|&k| k as u64));
    meta[16] = meta.len() as u64; meta.extend(spec.detached.iter().map(|&v| v as u64));
    meta[17] = meta.len() as u64; meta.resize(meta.len()+width,0);
    for &k in &spec.binary_states { let at = meta[17] as usize+k; meta[at] = 1; }
    meta[18] = meta.len() as u64; meta[19] = params.len() as u64;
    for l in 0..plan.sizes.len()-1 { for j in 0..plan.sizes[l+1] {
        meta.push(plan.threshold_reference(l,j).map_or(0, |[bank,k]| 1+parameter_offsets[bank]+k) as u64);
        params.push(f32_value(plan.threshold[l])?);
    }}
    meta[20] = params.len() as u64; params.extend(cast(plan.masks.iter().flatten().copied(),edges)?);
    meta[21] = params.len() as u64;
    params.extend(cast((0..t).map(|k| plan.time_at(start_tick+k as u64)),t)?);
    meta[22] = params.len() as u64; meta[23] = clocks as u64;
    if precise_time {
        meta[29]=meta.len() as u64;
        meta.extend((0..t).map(|k| plan.time_at(start_tick+k as u64).to_bits()));
    }
    if let Some(c) = &spec.clocks {
        let samples=c.samples(start_tick,t)?;
        if precise_time {for k in 0..t {let at=meta[29] as usize+k;meta[at]=samples[k*clocks].to_bits();}}
        params.extend(cast(samples.into_iter(),t*clocks)?);
    }
    meta[24] = params.len() as u64; meta[25] = noise_width as u64;
    let uniform_masks: Vec<u16> = spec.program_sets.iter().map(|p| equation::noise_masks(p.iter()).1).collect();
    for sample in 0..b { for tick in 0..t { for action in &spec.actions { for stream in 0..action.noise_streams {
        let uniform = uniform_masks[action.program_set.unwrap()] & (1 << stream) != 0;
        params.push(noise::device_sample(noise::event_sample(action.event_noise.as_ref(),uniform,plan.seed,sequence,sample as u64,action.noise_domain,
            action.noise_entity,start_tick+tick as u64,stream as u64), uniform));
    }}}}
    meta[26] = default_initial as u64; meta[27] = meta.len() as u64;
    meta.extend(spec.initial_parameters.iter().map(|r| r.map_or(0, |[bank,k]| 1+parameter_offsets[bank]+k) as u64));
    meta[28] = meta.len() as u64; meta.resize(meta.len()+width,0);
    for &k in &spec.integer_states { let at=meta[28] as usize+k; meta[at]=1; }
    meta[14] = meta.len() as u64;
    meta.extend_from_slice(&[mpi.map_or(1,|m|m.size) as u64,mpi.map_or(0,|m|m.rank) as u64,0,0,0]);
    meta[11] = meta.len() as u64; meta[12] = params.len() as u64;
    ensure(meta.len() as u128 == meta_count && params.len() as u128 == param_count, "dynamic GPU metadata admission mismatch")?;
    let x = cast(inputs.iter().flatten().flatten().copied(),b*t*i)?;
    let integer_parameters: std::collections::HashSet<_> = spec.integer_parameters.iter()
        .map(|&[bank,k]| parameter_offsets[bank]+k).collect();
    let pack = |value:f64, integer:bool| -> Result<f32> {
        if integer { Ok(f32::from_bits(equation::int32(value)? as u32)) } else { f32_value(value) }
    };
    let mut w=Vec::with_capacity(edges);
    for (k,&x) in state.weights.iter().flatten().enumerate() { w.push(pack(x,integer_parameters.contains(&k))?); }
    let mut v=Vec::with_capacity(b*width);
    for (k,&x) in initial.iter().flatten().enumerate() { v.push(pack(x,meta[meta[28] as usize+k%width]!=0)?); }
    ensure(w.len()==edges && v.len()==b*width, "dynamic GPU staging shape mismatch")?;
    let y = labels.iter().map(|&k| k as u64).collect::<Vec<_>>();
    let mut tape = vec![0f32;b*t*tape_width]; let mut spikes = vec![0f32;b*t*n];
    let mut live = vec![0f32;b*width]; let mut grad = vec![0f32;b*edges]; let mut adj = vec![0f32;b*width];
    let mut logits = vec![0f32;b*classes]; let mut losses = vec![0f32;b]; let mut error = vec![0 as c_char;2048];
    use std::ffi::{c_char,c_void,CStr,CString};
    #[cfg_attr(target_os="macos",link(name="System"))]
    #[cfg_attr(not(target_os="macos"),link(name="dl"))]
    extern "C" { fn dlopen(p:*const c_char,flags:i32)->*mut c_void; fn dlsym(h:*mut c_void,s:*const c_char)->*mut c_void; fn dlclose(h:*mut c_void)->i32; }
    struct Library(*mut c_void); impl Drop for Library {fn drop(&mut self){unsafe{dlclose(self.0);}}}
    let path = CString::new(std::env::var(if plan.backend=="cuda" {"B2_TRAIN_CUDA_LIB"} else {"B2_TRAIN_METAL_LIB"})
        .map_err(|_| "dynamic GPU requires the selected native library; refusing CPU fallback")?)?;
    let handle = unsafe{dlopen(path.as_ptr(),2)}; ensure(!handle.is_null(),"cannot load dynamic GPU library")?;
    let _library = Library(handle);
    let symbol = CString::new(if plan.backend=="cuda" {"b2_train_cuda_v5r7"} else {"b2_train_metal_v5r7"})?;
    let function = unsafe{dlsym(handle,symbol.as_ptr())}; ensure(!function.is_null(),"dynamic GPU ABI symbol missing")?;
    type Kernel = unsafe extern "C" fn(*const u64,*const f32,*const f32,*const f32,*const f32,*const u64,
        *mut f32,*mut f32,*mut f32,*mut f32,*mut f32,*mut f32,*mut f32,*mut c_char,usize)->i32;
    let kernel:Kernel = unsafe{std::mem::transmute(function)};
    let code = unsafe{kernel(meta.as_ptr(),params.as_ptr(),x.as_ptr(),w.as_ptr(),v.as_ptr(),y.as_ptr(),tape.as_mut_ptr(),
        spikes.as_mut_ptr(),live.as_mut_ptr(),grad.as_mut_ptr(),adj.as_mut_ptr(),logits.as_mut_ptr(),losses.as_mut_ptr(),error.as_mut_ptr(),error.len())};
    ensure(code==0,&format!("native dynamic GPU failed: {}",unsafe{CStr::from_ptr(error.as_ptr())}.to_string_lossy()))?;
    ensure(spikes.iter().chain(&grad).chain(&adj).chain(&logits).chain(&losses).all(|x| x.is_finite())
        && live.iter().enumerate().all(|(k,x)| meta[meta[28] as usize+k%width]!=0 || x.is_finite()),"nonfinite dynamic GPU result")?;
    let mut gradients = state.weights.iter().map(|w| vec![0.;w.len()]).collect::<Vec<_>>();
    for (bank,row) in gradients.iter_mut().enumerate() { for (k,g) in row.iter_mut().enumerate() {
        for sample in 0..b { *g += grad[sample*edges+parameter_offsets[bank]+k] as f64 * plan.masks[bank][k]; }
    }}
    if let Some(m) = mpi { for row in &mut gradients { m.sum(row)?; } }
    if operation=="train" {apply_optimizer_distributed(plan,&mut state,&gradients,mpi)?;}
    let rows = |values:&[f32],w:usize| values.chunks_exact(w).map(|r| r.iter().map(|&v| v as f64).collect::<Vec<_>>()).collect::<Vec<_>>();
    let voltages = |values:&[f32]| values.chunks_exact(width).map(|r| spec.voltage.iter().map(|&k|r[k] as f64).collect()).collect();
    Ok(Output { updated_dynamic: None,schema:"b2-lif-training-result-v1",state,loss:losses.iter().map(|&v|v as f64).sum::<f64>()/b as f64,
        backend:if plan.backend=="cuda" {"cuda"} else {"metal"},
        numeric_profile:match(plan.backend.as_str(),mpi.is_some()) {
            ("cuda",true)=>"native-cuda-mpi-dynamic-actions-f32-owner-host-optimizer-f64",
            ("cuda",false)=>"native-cuda-dynamic-actions-f32-host-optimizer-f64",
            (_,true)=>"native-metal-mpi-dynamic-actions-f32-owner-host-optimizer-f64",
            (_,false)=>"native-metal-dynamic-actions-f32-host-optimizer-f64"},
        gpu_dispatches:if mpi.is_some(){3+t*(2*spec.actions.len()+if operation=="evaluate"{0}else{1+2*spec.actions.len()})}else{1},
        gradients,initial_gradients:voltages(&adj),final_membrane:voltages(&live),
        initial_state_gradients:Some(rows(&adj,width)),final_state:Some(live.chunks_exact(width).map(|r| r.iter().enumerate()
            .map(|(k,&x)| if meta[meta[28] as usize+k]!=0 { x.to_bits() as i32 as f64 } else { x as f64 }).collect()).collect()),
        spikes:spikes.chunks_exact(t*n).map(|s|rows(s,n)).collect(),logits:rows(&logits,classes),tape_bytes:bytes+gpu_bytes,
        gradient_scope:if plan.tbptt_window.is_some_and(|w|w<t){"tbptt-detach-boundaries"}else{"full-bptt"},
        final_tick:None,noise_sequence:None})
}
