//! Native sequence-boundary replacement of external TimedArray values.
use super::*;

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Update {
    pub bank: usize,
    pub values: Vec<f64>,
}

pub(super) fn execute(plan: Plan, mut state: State, live: Option<Vec<Vec<f64>>>,
    update: Update, tick: u64, sequence: u64) -> Result<Output> {
    let spec = plan.dynamic.as_ref().ok_or("TimedArray update requires a dynamic plan")?;
    validate_state(&plan, &state)?;
    if let Some(rows) = &live { validate_live(&plan, rows)?; }
    ensure(tick <= (1u64 << 53) && plan.time_at(tick).is_finite(), "invalid input update clock")?;
    ensure(spec.program_sets.iter().flatten().flatten().any(|node|
        matches!(node, equation::Node::TimedParameter { bank, .. } if *bank == update.bank)),
        "input update bank must be read by a TimedArray node")?;
    ensure(!plan.trainable[update.bank] && update.values.len() == state.weights[update.bank].len()
        && update.values.iter().all(|v| v.is_finite()), "input update requires a frozen bank and finite matching values")?;
    ensure(plan.backend == "cpu" || update.values.iter().all(|&v| (v as f32).is_finite()),
        "GPU timed input values must be representable in float32")?;
    let bytes = spec.memory_bytes(live.as_ref().map_or(0, Vec::len), 0, plan.mpi_ranks.unwrap_or(1))
        .and_then(|n| state.weights.iter().try_fold(n, |s,w| s.checked_add(w.len().checked_mul(24)?)))
        .and_then(|n| n.checked_add(update.values.len().checked_mul(8)?)).ok_or("input update memory overflow")?;
    ensure(bytes <= plan.max_tape_bytes, "input update exceeds memory budget")?;
    state.weights[update.bank] = update.values;
    validate_state(&plan, &state)?;
    let membrane = live.as_ref().map_or_else(Vec::new, |rows|
        rows.iter().map(|row| spec.voltage.iter().map(|&k| row[k]).collect()).collect());
    Ok(Output { updated_dynamic: None,
        schema: "b2-lif-training-result-v1", state, final_state: live, final_membrane: membrane,
        final_tick: Some(tick), noise_sequence: plan.noise_streams.as_ref().map(|_| sequence),
        backend: "cpu", numeric_profile: "native-timed-input-update-f64", gpu_dispatches: 0,
        loss: 0.0, gradients: vec![], initial_gradients: vec![], initial_state_gradients: None,
        spikes: vec![], logits: vec![], tape_bytes: bytes, gradient_scope: "input-boundary-no-gradient",
    })
}
