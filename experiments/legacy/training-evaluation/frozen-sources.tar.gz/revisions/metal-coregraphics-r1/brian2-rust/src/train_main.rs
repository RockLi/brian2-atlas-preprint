//! Isolated native supervised-training CLI. Never invokes another ML runtime.
fn main() {
    let mut mpi = match b2_runner::training::mpi::Context::from_environment() {
        Ok(context) => context,
        Err(error) => {
            eprintln!("b2-train: {error}");
            std::process::exit(1);
        }
    };
    let result = (|| -> Result<(), Box<dyn std::error::Error>> {
        let args: Vec<_> = std::env::args_os().collect();
        if args.len() != 3 {
            return Err("usage: b2-train REQUEST.json RESULT.json".into());
        }
        if std::fs::metadata(&args[1])?.len() > 64 * 1024 * 1024 {
            return Err("training request exceeds 64 MiB input limit".into());
        }
        let bytes = std::fs::read(&args[1])?;
        if let Some(context) = &mpi {
            use sha2::{Digest, Sha256};
            let mut hash = Sha256::new();
            hash.update(&bytes);
            hash.update(std::fs::read(std::env::current_exe()?)?);
            hash.update(std::fs::read(std::env::var("B2_TRAIN_MPI_LIB")?)?);
            context.agree(&hash.finalize().into())?;
        }
        let request = serde_json::from_slice(&bytes)?;
        let result = b2_runner::training::execute_distributed(request, mpi.as_ref())?;
        if mpi.as_ref().is_none_or(|m| m.rank == 0) {
            std::fs::write(&args[2], serde_json::to_vec(&result)?)?;
        }
        if let Some(context) = &mut mpi {
            context.finish()?;
        }
        Ok(())
    })();
    if let Err(error) = result {
        eprintln!("b2-train: {error}");
        drop(mpi); // abort peers before exiting on a rank-local failure
        std::process::exit(1);
    }
}
