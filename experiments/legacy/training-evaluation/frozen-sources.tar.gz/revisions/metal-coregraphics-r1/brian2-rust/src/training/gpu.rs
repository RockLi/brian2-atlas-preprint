//! Shared native Metal/CUDA forward/VJP ABI. The optimizer remains native Rust on the host.
use super::*;

#[cfg(not(unix))]
pub(super) fn execute(
    _: &Plan,
    _: State,
    _: &[Vec<Vec<f64>>],
    _: &[usize],
    _: &[Vec<f64>],
    _: usize,
    _: &str,
    _: Option<&mpi::Context>,
    _: u64,
    _: u64,
) -> Result<Output> {
    Err("native GPU training requires a Unix host and the selected GPU".into())
}

#[cfg(unix)]
pub(super) fn execute(
    plan: &Plan,
    mut state: State,
    inputs: &[Vec<Vec<f64>>],
    labels: &[usize],
    initial: &[Vec<f64>],
    bytes: usize,
    operation: &str,
    mpi: Option<&mpi::Context>,
    start_tick: u64,
    noise_sequence: u64,
) -> Result<Output> {
    use std::ffi::{c_char, c_void, CStr, CString};
    #[cfg_attr(target_os = "macos", link(name = "System"))]
    #[cfg_attr(not(target_os = "macos"), link(name = "dl"))]
    extern "C" {
        fn dlopen(path: *const c_char, flags: i32) -> *mut c_void;
        fn dlsym(handle: *mut c_void, name: *const c_char) -> *mut c_void;
        fn dlclose(handle: *mut c_void) -> i32;
    }
    type Kernel = unsafe extern "C" fn(
        *const u64,
        *const f32,
        *const f32,
        *const f32,
        *const f32,
        *const u64,
        *mut f32,
        *mut f32,
        *mut f32,
        *mut f32,
        *mut f32,
        *mut f32,
        *mut f32,
        *mut c_char,
        usize,
    ) -> i32;
    let library = CString::new(
        std::env::var(if plan.backend == "cuda" {
            "B2_TRAIN_CUDA_LIB"
        } else {
            "B2_TRAIN_METAL_LIB"
        })
        .map_err(|_| "set the selected B2_TRAIN_METAL_LIB/B2_TRAIN_CUDA_LIB native library")?,
    )?;
    let handle = unsafe { dlopen(library.as_ptr(), 2) };
    ensure(
        !handle.is_null(),
        "cannot load native Metal training library",
    )?;
    struct Library(*mut c_void);
    impl Drop for Library {
        fn drop(&mut self) {
            unsafe {
                dlclose(self.0);
            }
        }
    }
    let _library = Library(handle);
    // Version the metadata ABI: a v1 library cannot silently execute a v2
    // projection plan as if it were a dense feedforward network.
    let vector = plan.state_equations.is_some();
    let phased = vector || mpi.is_some();
    let symbol = CString::new(if vector {
        if plan.backend == "cuda" {
            "b2_train_cuda_v4r7"
        } else {
            "b2_train_metal_v4r7"
        }
    } else if mpi.is_some() {
        if plan.backend == "cuda" {
            "b2_train_cuda_mpi_v1"
        } else {
            "b2_train_metal_mpi_v1"
        }
    } else {
        match (plan.backend.as_str(), plan.equations.is_some()) {
            ("cuda", true) => "b2_train_cuda_v3",
            ("cuda", false) => "b2_train_cuda_v2",
            (_, true) => "b2_train_metal_v3",
            (_, false) => "b2_train_metal_v2",
        }
    })?;
    let function = unsafe { dlsym(handle, symbol.as_ptr()) };
    ensure(
        !function.is_null(),
        "native Metal/CUDA training symbol missing",
    )?;
    let kernel: Kernel = unsafe { std::mem::transmute(function) };
    let batch = inputs.len();
    let time = inputs[0].len();
    let layers = plan.sizes.len() - 1;
    let (_, n) = plan.validate()?;
    let width = plan.state_width();
    let edges = state.weights.iter().map(Vec::len).sum::<usize>();
    let graph_edges = plan
        .projections
        .as_ref()
        .map_or(0, |ps| ps.iter().map(|p| p.sources.len()).sum::<usize>());
    // Metal has additional batch-private gradients, tape copies and scratch.
    // Both host f32 staging and Metal shared buffers remain live during the
    // dispatch. Include both copies, all three scratch arrays and metadata.
    let scalar_nodes = plan
        .equations
        .as_ref()
        .map_or(0, |ps| ps.iter().map(Vec::len).sum::<usize>());
    let vector_states = plan
        .state_equations
        .as_ref()
        .map_or(0, |ps| ps.iter().map(Vec::len).sum::<usize>());
    let equation_nodes = scalar_nodes
        + plan
            .state_equations
            .iter()
            .chain(plan.state_resets.iter())
            .flatten()
            .flatten()
            .map(Vec::len)
            .sum::<usize>();
    let tape_count = batch
        * time
        * if vector {
            2 * width + n
        } else {
            n * if plan.equations.is_some() {
                3
            } else if plan.projections.is_some() {
                2
            } else {
                1
            }
        };
    // Host staging + device buffers, per-sample scratch, metadata and the
    // largest host-staged collective (CUDA also needs a float32 copy).
    let noise_width = plan.noise_streams.as_ref().map_or(0, |counts| counts.iter().zip(&plan.sizes[1..]).map(|(c, n)| c * n).sum::<usize>());
    let noise_count = batch * time * noise_width;
    let gpu_bytes = (2 * tape_count
        + 2 * batch * time * n
        + batch * width * 12
        + batch * edges * 2
        + edges * 2
        + batch * time * plan.sizes[0] * 2
        + batch * (plan.sizes[layers] * 2 + 2))
        * 4
        + mpi.map_or(0, |m| width * 8 * (m.size + 3) + 128)
        + graph_edges * 64
        + 84 * 16
        + equation_nodes * 80
        + layers * 128
        + vector_states * 96
        + batch * 128 * 16
        + if plan.clock.is_some() { time * 8 } else { 0 }
        + noise_count * 8 + if noise_width > 0 { (2 + 2 * layers) * 16 } else { 0 };
    ensure(
        bytes
            .checked_add(gpu_bytes)
            .is_some_and(|total| total <= plan.max_tape_bytes),
        if plan.backend == "cuda" {
            "native CUDA tape budget exceeded"
        } else {
            "native Metal tape budget exceeded"
        },
    )?;
    let equation_meta = if plan.equations.is_some() {
        3 * layers + 4 * scalar_nodes
    } else {
        0
    };
    let threshold_meta = if plan.threshold_parameters.is_some() {
        if vector { n } else { layers }
    } else {
        0
    };
    // Reserve the complete v3 layout before appending: growing an already
    // large graph Vec could otherwise double its unaccounted host capacity.
    let mut meta = Vec::with_capacity(
        84 + graph_edges * 4
            + equation_meta
            + threshold_meta
            + if phased { 4 } else { 0 }
            + if vector {
                1 + 6 * layers + 6 * vector_states + 4 * equation_nodes
            } else {
                0
            },
    );
    meta.resize(84, 0u64);
    for (i, value) in [
        batch,
        time,
        layers,
        plan.sizes[0],
        n,
        edges,
        usize::from(plan.reset == "zero"),
        usize::from(plan.detach_reset),
        plan.tbptt_window.unwrap_or(time),
        usize::from(operation != "evaluate"),
    ]
    .iter()
    .enumerate()
    {
        meta[i] = *value as u64;
    }
    for l in 0..=layers {
        meta[16 + l] = plan.sizes[l] as u64;
    }
    let mut neuron = 0;
    for l in 0..layers {
        meta[40 + l] = neuron as u64;
        neuron += plan.sizes[l + 1];
    }
    meta[40 + layers] = neuron as u64;
    let mut parameter_offsets = vec![0usize];
    for weights in &state.weights {
        parameter_offsets.push(parameter_offsets.last().unwrap() + weights.len());
    }
    if let Some(projections) = &plan.projections {
        meta[10] = graph_edges as u64;
        for (q, p) in projections.iter().enumerate() {
            for e in 0..p.sources.len() {
                let source = if p.source_layer == 0 {
                    p.sources[e]
                } else {
                    meta[39 + p.source_layer] as usize + p.sources[e]
                };
                let target = meta[39 + p.target_layer] as usize + p.targets[e];
                meta.extend_from_slice(&[
                    u64::from(p.source_layer == 0),
                    source as u64,
                    target as u64,
                    (parameter_offsets[q] + p.parameter_ids[e]) as u64,
                ]);
            }
        }
    } else {
        for (l, &offset) in parameter_offsets.iter().enumerate() {
            meta[64 + l] = offset as u64;
        }
    }
    fn cast(values: impl IntoIterator<Item = f64>, count: usize) -> Result<Vec<f32>> {
        let mut converted = Vec::with_capacity(count);
        for v in values {
            let value = v as f32;
            ensure(value.is_finite(), "native GPU float32 input overflow")?;
            converted.push(value);
        }
        Ok(converted)
    }
    let mut equation_constants = Vec::with_capacity(equation_nodes);
    if let Some(programs) = &plan.equations {
        meta[11] = meta.len() as u64;
        let header = meta.len();
        meta.resize(header + 3 * layers, 0);
        for (l, program) in programs.iter().enumerate() {
            meta[header + 3 * l] = program.len() as u64;
            meta[header + 3 * l + 1] = meta.len() as u64;
            meta[header + 3 * l + 2] = (2 * layers + 3 + equation_constants.len()) as u64;
            for node in program {
                let (row, value) = equation::gpu_node(node, &parameter_offsets);
                meta.extend_from_slice(&row);
                equation_constants.push(value);
            }
        }
    }
    if let Some(updates) = &plan.state_equations {
        let resets = plan.state_resets.as_ref().unwrap();
        meta[83] = meta.len() as u64;
        let header = meta.len();
        meta.resize(header + 1 + 6 * layers, 0);
        meta[header] = width as u64;
        let mut state_offset = 0;
        for l in 0..layers {
            let h = header + 1 + 6 * l;
            meta[h] = updates[l].len() as u64;
            meta[h + 1] = state_offset as u64;
            if let Some(spec) = plan.refractory.as_ref().and_then(|r| r[l].as_ref()) {
                meta[h + 4] = spec.steps as u64 + 1;
                meta[h + 5] = spec.clamp.iter().fold(0, |mask, &s| mask | (1u64 << s));
            }
            state_offset += updates[l].len() * plan.sizes[l + 1];
            for (kind, programs) in [&updates[l], &resets[l]].iter().enumerate() {
                let headers = meta.len();
                meta[h + 2 + kind] = headers as u64;
                meta.resize(headers + 3 * programs.len(), 0);
                for (i, program) in programs.iter().enumerate() {
                    meta[headers + 3 * i] = program.len() as u64;
                    meta[headers + 3 * i + 1] = meta.len() as u64;
                    meta[headers + 3 * i + 2] = (2 * layers + 3 + equation_constants.len()) as u64;
                    for node in program {
                        let (row, value) = equation::gpu_node(node, &parameter_offsets);
                        meta.extend_from_slice(&row);
                        equation_constants.push(value);
                    }
                }
            }
        }
    }
    if let Some(references) = &plan.threshold_parameters {
        meta[14] = meta.len() as u64;
        for l in 0..references.len() {
            for j in 0..if vector { plan.sizes[l + 1] } else { 1 } {
                meta.push(plan.threshold_reference(l, j).map_or(0, |[bank, index]| {
                    (parameter_offsets[bank] + index + 1) as u64
                }));
            }
        }
    }
    if phased {
        meta[15] = meta.len() as u64;
        meta.extend_from_slice(&[
            mpi.map_or(1, |m| m.size) as u64,
            mpi.map_or(0, |m| m.rank) as u64,
            0,
            0,
        ]);
    }
    if let Some(m) = mpi {
        use sha2::{Digest, Sha256};
        m.agree(&Sha256::digest(std::fs::read(library.to_str()?)?).into())?;
    }
    meta[12] = meta.len() as u64;
    meta[13] = (2 * layers + 3 + equation_constants.len()) as u64;
    let mut params = cast(
        [
            plan.beta.clone(),
            plan.threshold.clone(),
            vec![plan.surrogate.slope, plan.surrogate.scale, plan.logit_scale],
        ]
        .concat(),
        2 * layers + 3,
    )?;
    params.extend(cast(equation_constants, equation_nodes)?);
    if plan.clock.is_some() {
        meta[82] = params.len() as u64;
        let times = cast((0..time).map(|t| plan.time_at(start_tick + t as u64)), time)?;
        ensure(times.windows(2).all(|w| w[1] > w[0])
            && (plan.time_at(start_tick + time as u64) as f32).is_finite()
            && (plan.time_at(start_tick + time as u64) as f32) > times[time - 1],
            "GPU clock has insufficient float32 precision")?;
        params.extend(times);
        meta[13] = params.len() as u64;
    }
    if let Some(counts) = &plan.noise_streams {
        meta[81] = meta.len() as u64;
        meta.reserve_exact(2 + 2 * layers);
        meta.push(params.len() as u64);
        meta.push(noise_width as u64);
        let mut offset = 0;
        for l in 0..layers {
            meta.extend_from_slice(&[counts[l] as u64, offset as u64]);
            offset += counts[l] * plan.sizes[l + 1];
        }
        params.reserve_exact(noise_count);
        for b in 0..batch {
            for t in 0..time {
                for l in 0..layers {
                    let uniform = equation::noise_masks(plan.state_equations.as_ref().unwrap()[l].iter()
                        .chain(&plan.state_resets.as_ref().unwrap()[l])).1;
                    for j in 0..plan.sizes[l + 1] {
                        let values = plan.noise_at(uniform, noise_sequence, b, l, j, start_tick + t as u64);
                        params.extend(values[..counts[l]].iter().enumerate().map(|(stream, &v)|
                            noise::device_sample(v, uniform & (1 << stream) != 0)));
                    }
                }
            }
        }
        meta[12] = meta.len() as u64;
        meta[13] = params.len() as u64;
    }
    let x = cast(
        inputs.iter().flatten().flatten().copied(),
        batch * time * plan.sizes[0],
    )?;
    let w = cast(state.weights.iter().flatten().copied(), edges)?;
    let v = cast(initial.iter().flatten().copied(), batch * width)?;
    let y = labels.iter().map(|&v| v as u64).collect::<Vec<_>>();
    let mut pre = vec![0f32; tape_count];
    let mut spikes = vec![0f32; batch * time * n];
    let mut final_v = vec![0f32; batch * width];
    let mut grad = vec![0f32; batch * edges];
    let mut initial_grad = final_v.clone();
    let classes = plan.sizes[layers];
    let mut logits = vec![0f32; batch * classes];
    let mut loss = vec![0f32; batch];
    let mut error = vec![0 as c_char; 2048];
    let code = unsafe {
        kernel(
            meta.as_ptr(),
            params.as_ptr(),
            x.as_ptr(),
            w.as_ptr(),
            v.as_ptr(),
            y.as_ptr(),
            pre.as_mut_ptr(),
            spikes.as_mut_ptr(),
            final_v.as_mut_ptr(),
            grad.as_mut_ptr(),
            initial_grad.as_mut_ptr(),
            logits.as_mut_ptr(),
            loss.as_mut_ptr(),
            error.as_mut_ptr(),
            error.len(),
        )
    };
    if code != 0 {
        return Err(format!(
            "native GPU training failed: {}",
            unsafe { CStr::from_ptr(error.as_ptr()) }.to_string_lossy()
        )
        .into());
    }
    ensure(
        spikes
            .iter()
            .chain(&final_v)
            .chain(&grad)
            .chain(&initial_grad)
            .chain(&logits)
            .chain(&loss)
            .all(|v| v.is_finite()),
        "nonfinite native GPU training output",
    )?;
    let mut gradients = state
        .weights
        .iter()
        .map(|w| vec![0.0; w.len()])
        .collect::<Vec<_>>();
    for l in 0..gradients.len() {
        for e in 0..gradients[l].len() {
            for b in 0..batch {
                gradients[l][e] +=
                    grad[b * edges + parameter_offsets[l] + e] as f64 * plan.masks[l][e];
            }
        }
    }
    if let Some(m) = mpi {
        for row in &mut gradients {
            m.sum(row)?;
        }
    }
    if operation == "train" {
        apply_optimizer_distributed(plan, &mut state, &gradients, mpi)?;
    }
    let rows = |values: &[f32], width: usize| {
        values
            .chunks_exact(width)
            .map(|row| row.iter().map(|&v| v as f64).collect())
            .collect()
    };
    let rows: fn(&[f32], usize) -> Vec<Vec<f64>> = rows;
    let voltage_rows = |values: &[f32]| {
        let all = rows(values, width);
        if !vector {
            return all;
        }
        all.iter()
            .map(|row| {
                (0..layers)
                    .flat_map(|l| {
                        let offset = meta[meta[83] as usize + 2 + 6 * l] as usize;
                        row[offset..offset + plan.sizes[l + 1]].iter().copied()
                    })
                    .collect()
            })
            .collect()
    };
    let shaped = spikes
        .chunks_exact(time * n)
        .map(|sample| rows(sample, n))
        .collect();
    Ok(Output { updated_dynamic: None,
        final_tick: None,
        noise_sequence: None,
        schema: "b2-lif-training-result-v1",
        state,
        loss: loss.iter().map(|&v| v as f64).sum::<f64>() / batch as f64,
        backend: if plan.backend == "cuda" {
            "cuda"
        } else {
            "metal"
        },
        numeric_profile: if vector {
            match (plan.backend.as_str(), mpi.is_some()) {
                ("cuda", true) => "native-cuda-mpi-multistate-target-owned-f32-host-optimizer-f64",
                ("cuda", false) => "native-cuda-multistate-f32-host-optimizer-f64",
                (_, true) => "native-metal-mpi-multistate-target-owned-f32-host-optimizer-f64",
                (_, false) => "native-metal-multistate-f32-host-optimizer-f64",
            }
        } else if mpi.is_some() && plan.backend == "cuda" {
            "native-cuda-mpi-target-owned-f32-host-optimizer-f64"
        } else if mpi.is_some() {
            "native-metal-mpi-target-owned-f32-host-optimizer-f64"
        } else if plan.backend == "cuda" {
            "native-cuda-forward-backward-f32-host-optimizer-f64"
        } else {
            "native-metal-forward-backward-f32-host-optimizer-f64"
        },
        gpu_dispatches: if phased {
            3 + time * if operation == "evaluate" { 2 } else { 4 }
        } else {
            1
        },
        gradients,
        initial_gradients: voltage_rows(&initial_grad),
        final_membrane: voltage_rows(&final_v),
        final_state: vector.then(|| rows(&final_v, width)),
        initial_state_gradients: vector.then(|| rows(&initial_grad, width)),
        spikes: shaped,
        logits: rows(&logits, classes),
        tape_bytes: bytes + gpu_bytes,
        gradient_scope: if plan.tbptt_window.is_some_and(|w| w < time) {
            "tbptt-detach-boundaries"
        } else {
            "full-bptt"
        },
    })
}
