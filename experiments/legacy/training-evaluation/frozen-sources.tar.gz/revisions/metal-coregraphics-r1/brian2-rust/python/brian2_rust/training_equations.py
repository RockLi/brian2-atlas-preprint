"""Bounded scalar update expressions compiled to native differentiable SSA.

An expression is the discrete pre-threshold voltage update. Unit conversion and
integration step choice belong to the caller; arbitrary Brian statements and
Python execution are deliberately not accepted by this compiler.
"""
import ast
import math
from dataclasses import dataclass


@dataclass(frozen=True)
class TimedInput:
    bank: int
    rows: int
    columns: int
    epsilon: float
    k: int
    dimensions: int



@dataclass(frozen=True)
class NeuronParameter:
    """Contiguous parameter slice indexed by the layer-local neuron number."""
    bank: int
    index: int = 0
    dtype: str = "float"


@dataclass(frozen=True)
class _MappedParameter:
    """Canonical parameter read through a fixed neuron-index mapping."""
    bank: int
    mapping: int
    dtype: str = "float"


@dataclass(frozen=True)
class ParameterBank:
    """Callable canonical bank read using a detached int32 SSA selector.

    Bind a name to this descriptor and use ``name(index)`` in a typed dynamic
    expression. Integer banks are frozen; float bank values keep their VJP.
    """
    bank: int
    dtype: str = "float"


@dataclass(frozen=True)
class _DeferredParameter:
    """Private Brian reference resolved after canonical state allocation."""
    bank: int
    reference: int
    dtype: str = "float"


@dataclass(frozen=True)
class SimulationTime:
    """Read the current tick's SI time from a v4 execution clock."""


@dataclass(frozen=True)
class ClockTime:
    """Read a v5 clock at the current neuron tick; clock scheduling is detached."""
    index: int


@dataclass(frozen=True)
class IntegerParameter:
    """A frozen int32 parameter slot in the dynamic ABI."""
    bank: int
    index: int


@dataclass(frozen=True)
class BooleanParameter:
    bank: int
    index: int


@dataclass(frozen=True)
class StateSlot:
    """A v5 action-context slot (including synaptic or referenced neuron state)."""
    index: int
    dtype: str = "float"


@dataclass(frozen=True)
class NormalNoise:
    """A standard normal draw shared by uses of a declared per-neuron stream."""
    stream: int


@dataclass(frozen=True)
class UniformNoise:
    """A native uniform [0, 1) draw at a declared per-entity call site."""
    stream: int


def compile_training_equation(expression, *, parameters=None, states=None, state_types=None):
    """Compile v_next=f(v, parameters); parameter values are constants or (bank,id).

    Supports +,-,*,/, literal powers, exp/log/tanh/sqrt/sin/cos. A (bank,id)
    reference shares that native optimizer slot with every other use.
    """
    if not isinstance(expression,str) or len(expression)>8192:
        raise ValueError('training equation must be a bounded expression')
    try:root=ast.parse(expression,mode='eval').body
    except (SyntaxError,RecursionError):raise ValueError('invalid or excessively nested equation') from None
    return _compile_training_ast(root,parameters=parameters,states=states,state_types=state_types)


def compile_training_predicate(expression, *, parameters, states, slope=5., scale=1., state_types=None):
    """Boolean threshold with ordered, short-circuit surrogate gates.

    Ordered comparisons differentiate their SI margin. Equality is detached.
    A skipped Boolean operand acts as its operator's neutral element in VJP.
    """
    if not isinstance(expression,str) or len(expression)>8192:
        raise ValueError('threshold must be a bounded expression')
    if any(type(v) not in (int,float) or not math.isfinite(v) or v<=0 for v in (slope,scale)):
        raise ValueError('predicate surrogate coefficients must be finite and positive')
    try:root=ast.parse(expression,mode='eval').body
    except (SyntaxError,RecursionError):raise ValueError('invalid threshold expression') from None
    return _compile_training_ast(root,parameters=parameters,states=states,predicate_surrogate=(slope,scale),state_types=state_types)


def _compile_training_ast(root, *, parameters=None, states=None, deduplicate=False, refractory_index=None, allow_select=False, predicate_surrogate=None, state_types=None, typed=False):
    """Compile an immutable expression DAG, retaining shared RK stage nodes."""
    parameters={} if parameters is None else dict(parameters)
    states=[] if states is None else list(states)
    if states and (states[0]!='v' or len(states)>16 or len(set(states))!=len(states)
                   or any(not isinstance(n,str) or not n.isidentifier() for n in states)):
        raise ValueError('states require 1..16 unique names with v first')
    if set(parameters)&(set(states)|{'v'}):raise ValueError('state names are reserved')
    types={} if state_types is None else dict(zip(states,state_types))
    typed=typed or state_types is not None
    if any(t not in ('float','integer','boolean') for t in types.values()):raise ValueError('invalid state type')
    nodes=[];memo={};emitted={}
    def emit(op,**fields):
        key=(op,*((name,value.hex() if isinstance(value,float) else value) for name,value in fields.items()))
        if deduplicate and key in emitted:return emitted[key]
        if len(nodes)>=128:raise ValueError('training equation exceeds 128 nodes')
        nodes.append(dict(op=op,**fields));emitted[key]=len(nodes)-1;return len(nodes)-1
    integer_ops={'integer_constant','integer_state','integer_parameter','integer_neuron_parameter','integer_mapped_parameter','integer_parameter_gather','_deferred_integer_parameter','integer_cast','integer_binary','integer_select','integer_neg'}
    def integer(index):return nodes[index]['op'] in integer_ops
    def floating(index):return emit('integer_float',arg=index) if integer(index) else index
    def binary(op,left,right):
        if typed and integer(left) and integer(right) and op in ('add','sub','mul','min','max','floor_div','mod'):
            return emit('integer_binary',left=left,right=right,kind=op)
        return emit('modulo' if op=='mod' else op,left=floating(left),right=floating(right))
    def constant(value):
        if typed and type(value) is bool:return emit('constant',value=float(value))
        if typed and type(value) is int:
            if not -2**31<=value<2**31:raise ValueError('integer literal is outside int32')
            return emit('integer_constant',value=value)
        if type(value) not in (int,float) or not math.isfinite(value):
            raise ValueError('equation constants must be finite real numbers')
        return emit('constant',value=float(value))
    def visit(node):
        key=id(node)
        if key not in memo:memo[key]=lower(node)
        return memo[key]
    def lower(node):
        if predicate_surrogate is not None or typed:
            if isinstance(node,ast.Constant) and type(node.value) is bool:
                return emit("constant",value=float(node.value))
            if isinstance(node,ast.UnaryOp) and isinstance(node.op,ast.Not):
                return emit('boolean_not',arg=visit(node.operand))
            if isinstance(node,ast.BoolOp):
                op='boolean_and' if isinstance(node.op,ast.And) else 'boolean_or'
                result=visit(node.values[0])
                for child in node.values[1:]:result=emit(op,left=result,right=visit(child))
                return result
            if isinstance(node,ast.Compare):
                left=visit(node.left);result=None
                for op,child in zip(node.ops,node.comparators):
                    right=visit(child)
                    kind={ast.Gt:'gt',ast.GtE:'ge',ast.Lt:'lt',ast.LtE:'le',ast.Eq:'eq',ast.NotEq:'ne'}.get(type(op))
                    if kind is None:raise ValueError('unsupported comparison')
                    if typed and integer(left) and integer(right):
                        current=emit('integer_compare',left=left,right=right,kind=kind)
                    elif predicate_surrogate is None:
                        current=emit('discrete_compare',left=floating(left),right=floating(right),kind=kind)
                    elif isinstance(op,(ast.Eq,ast.NotEq)):
                        current=emit('equality',left=floating(left),right=floating(right),unequal=isinstance(op,ast.NotEq))
                    elif isinstance(op,(ast.Gt,ast.GtE,ast.Lt,ast.LtE)):
                        a,b=(left,right) if isinstance(op,(ast.Gt,ast.GtE)) else (right,left)
                        margin=binary('sub',a,b)
                        current=emit('surrogate_step',arg=margin,slope=constant(float(predicate_surrogate[0])),
                                     scale=constant(float(predicate_surrogate[1])),inclusive=isinstance(op,(ast.GtE,ast.LtE)))
                    else:raise ValueError('unsupported threshold comparison')
                    result=current if result is None else emit('boolean_and',left=result,right=current)
                    left=right
                return result
        if allow_select and isinstance(node,ast.IfExp):
            condition=visit(node.test);yes=visit(node.body);no=visit(node.orelse)
            if integer(yes) and integer(no):return emit('integer_select',condition=condition,yes=yes,no=no)
            return emit('select',condition=condition,yes=floating(yes),no=floating(no))
        if isinstance(node,ast.Constant):return constant(node.value)
        if isinstance(node,ast.Name):
            if node.id=='_b2_refractory_active' and refractory_index is not None:
                return emit('refractory_active',index=refractory_index)
            if node.id in states:
                index=emit('integer_state' if types.get(node.id)=='integer' else 'state',index=states.index(node.id))
                return emit('boolean_cast',arg=index) if types.get(node.id)=='boolean' else index
            if node.id=='v':return emit('voltage')
            if node.id not in parameters:raise ValueError('unknown equation name: '+node.id)
            value=parameters[node.id]
            if isinstance(value,StateSlot):
                if not states or type(value.index) is not int or not 0<=value.index<64:
                    raise ValueError('state slot requires a bounded v5 action context')
                index=emit('integer_state' if value.dtype=='integer' else 'state',index=value.index)
                return emit('boolean_cast',arg=index) if value.dtype=='boolean' else index
            if isinstance(value,(NormalNoise,UniformNoise)):
                if not states or type(value.stream) is not int or not 0<=value.stream<16:
                    raise ValueError('noise requires v4 states and stream 0..15')
                return emit('uniform_noise' if isinstance(value,UniformNoise) else 'noise',stream=value.stream)
            if isinstance(value,SimulationTime):
                if not states:raise ValueError('simulation time requires v4 states')
                return emit('time')
            if isinstance(value,ClockTime):
                if not allow_select or type(value.index) is not int or not 0<=value.index<256:
                    raise ValueError('clock time requires a bounded v5 clock index')
                return emit('clock_time',index=value.index)
            if isinstance(value,NeuronParameter):
                if not states or any(type(i) is not int or i<0 for i in (value.bank,value.index)):
                    raise ValueError('neuron parameter requires v4 states and valid bank/index')
                index=emit('integer_neuron_parameter' if value.dtype=='integer' else 'neuron_parameter',bank=value.bank,index=value.index)
                return emit('boolean_cast',arg=index) if value.dtype=='boolean' else index
            if isinstance(value,_MappedParameter):
                if not states:raise ValueError('mapped parameters require state conversion')
                index=emit('integer_mapped_parameter' if value.dtype=='integer' else 'mapped_parameter',bank=value.bank,mapping=value.mapping)
                return emit('boolean_cast',arg=index) if value.dtype=='boolean' else index
            if isinstance(value,_DeferredParameter):
                if not typed or not states:raise ValueError('deferred Brian parameters require typed state conversion')
                index=emit('_deferred_integer_parameter' if value.dtype=='integer' else '_deferred_parameter',bank=value.bank,reference=value.reference)
                return emit('boolean_cast',arg=index) if value.dtype=='boolean' else index
            if isinstance(value,BooleanParameter):return emit('boolean_cast',arg=emit('parameter',bank=value.bank,index=value.index))
            if isinstance(value,IntegerParameter):return emit('integer_parameter',bank=value.bank,index=value.index)
            if isinstance(value,(tuple,list)) and len(value)==2:
                if any(type(i) is not int or i<0 for i in value):raise ValueError('invalid parameter reference')
                return emit('parameter',bank=value[0],index=value[1])
            return constant(value)
        if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.USub,ast.UAdd)):
            if typed and isinstance(node.op,ast.USub) and isinstance(node.operand,ast.Constant) and type(node.operand.value) is int:
                return constant(-node.operand.value)
            arg=visit(node.operand)
            return emit('integer_neg' if integer(arg) else 'neg',arg=arg) if isinstance(node.op,ast.USub) else arg
        if isinstance(node,ast.BinOp):
            if isinstance(node.op,ast.Pow):
                try:value=ast.literal_eval(node.right)
                except (ValueError,TypeError):raise ValueError('equation powers require a literal exponent') from None
                if type(value) not in (int,float) or not math.isfinite(value):raise ValueError('invalid exponent')
                return emit('pow',arg=floating(visit(node.left)),value=float(value))
            op={ast.Add:'add',ast.Sub:'sub',ast.Mult:'mul',ast.Div:'div',ast.FloorDiv:'floor_div',ast.Mod:'mod'}.get(type(node.op))
            if op:
                left=visit(node.left);right=visit(node.right)
                if op=='mod':
                    # Match Brian's Cython renderer, including its intermediate
                    # int32 wrap and floating cancellation at boundaries.
                    return binary('mod',binary('add',binary('mod',left,right),right),right)
                return binary(op,left,right)
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and isinstance(parameters.get(node.func.id),ParameterBank):
            source=parameters[node.func.id]
            if not typed or not states or node.keywords or len(node.args)!=1 or type(source.bank) is not int or source.bank<0 or source.dtype not in ('float','integer','boolean'):
                raise ValueError('parameter bank gather requires a typed dynamic expression and one index')
            index=visit(node.args[0])
            if not integer(index):raise ValueError('parameter bank selector must be int32')
            value=emit('integer_parameter_gather' if source.dtype=='integer' else 'parameter_gather',bank=source.bank,index=index)
            return emit('boolean_cast',arg=value) if source.dtype=='boolean' else value
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and isinstance(parameters.get(node.func.id),TimedInput):
            source=parameters[node.func.id]
            if not states or node.keywords or len(node.args)!=source.dimensions:
                raise ValueError('TimedArray call has invalid arguments')
            time=floating(visit(node.args[0]));index=floating(visit(node.args[1])) if source.dimensions==2 else emit('constant',value=0.)
            return emit('timed_parameter',bank=source.bank,rows=source.rows,columns=source.columns,
                        epsilon=source.epsilon,k=source.k,time=time,index=index)
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and not node.keywords:
            if node.func.id=='_b2_mod' and len(node.args)==2:
                return binary('mod',visit(node.args[0]),visit(node.args[1]))
            if typed and node.func.id in ('int','bool','_b2_float') and len(node.args)==1:
                arg=visit(node.args[0])
                if node.func.id=='int':return arg if integer(arg) else emit('integer_cast',arg=arg)
                if node.func.id=='_b2_float':return floating(arg)
                return emit('boolean_cast',arg=floating(arg))
            if typed and node.func.id=='floor' and len(node.args)==1:
                return binary('floor_div',floating(visit(node.args[0])),emit('constant',value=1.))
            if node.func.id=='clip' and len(node.args)==3:
                value,lo,hi=map(visit,node.args)
                return binary('min',binary('max',value,lo),hi)
            if node.func.id in ('minimum','maximum') and len(node.args)==2:
                return binary('min' if node.func.id=='minimum' else 'max',visit(node.args[0]),visit(node.args[1]))
        if (isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and
                node.func.id in ('exp','log','tanh','sqrt','sin','cos') and
                len(node.args)==1 and not node.keywords):
            return emit(node.func.id,arg=floating(visit(node.args[0])))
        raise ValueError('unsupported training equation expression')
    try:root=visit(root)
    except RecursionError:raise ValueError('invalid or excessively nested equation') from None
    # Unary plus may return an existing root, which is already the last node.
    return nodes[:root+1]


def neuron_parameter_bank(count, *, target_layer=1):
    """A v3 parameter bank with no synaptic edges, for equation coefficients."""
    if type(count) is not int or count<1:raise ValueError('parameter count must be positive')
    return dict(source_layer=0,target_layer=target_layer,parameter_count=count,
                sources=[],targets=[],parameter_ids=[])


def coerce_state_expression(expression, dtype):
    """Materialize Brian assignment conversion before the next statement."""
    function={'integer':'int','boolean':'bool','float':'_b2_float'}[dtype]
    return ast.Call(func=ast.Name(id=function,ctx=ast.Load()),args=[expression],keywords=[])


def typed_parameter(bank, index, dtype):
    return IntegerParameter(bank,index) if dtype=='integer' else BooleanParameter(bank,index) if dtype=='boolean' else (bank,index)
