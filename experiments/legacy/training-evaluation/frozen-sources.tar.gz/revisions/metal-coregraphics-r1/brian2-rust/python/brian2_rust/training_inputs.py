"""Conversion-time registry for native Brian TimedArray reads."""
import math
import numpy as np
from brian2.input.timedarray import TimedArray, _find_K


from .training_equations import TimedInput

class TimedInputRegistry:
    def __init__(self):
        self.sources={}
        self.entries=[]

    def resolve(self, value, owner, name, allocate, *, max_values):
        if type(value) is not TimedArray:
            raise ValueError('native timed inputs require an unmodified Brian TimedArray type')
        values=np.asarray(value.values)
        if (values.ndim not in (1,2) or not 0<values.size<=max_values or any(n==0 for n in values.shape)
                or not np.all(np.isfinite(values))):
            raise ValueError('TimedArray requires finite nonempty 1D/2D values within the input budget')
        # Brian Cython/C++ emits dt as an 18-place decimal literal.
        dt=float(value.dt);emitted_dt=float(f'{dt:.18f}')
        if not math.isfinite(dt) or emitted_dt<=0:raise ValueError('invalid TimedArray dt')
        ratio=8/float(owner.clock.dt_)*dt
        if not math.isfinite(ratio) or ratio>2**53:raise ValueError("TimedArray time resolution is not representable")
        # CodeObject.owner is the group, even when a pathway runs on another clock.
        k=_find_K(float(owner.clock.dt_),dt);epsilon=emitted_dt/k
        if k>2**53 or not math.isfinite(epsilon) or epsilon<=0:
            raise ValueError('TimedArray time resolution is not representable')
        identity=id(value)
        if identity not in self.sources:
            bank=allocate(value.name,values.reshape(-1))
            self.sources[identity]=bank
            self.entries.append(dict(name=value.name,bank=bank,shape=list(values.shape),dt_seconds=dt,aliases=[]))
        bank=self.sources[identity];entry=next(e for e in self.entries if e['bank']==bank)
        alias=dict(object=owner.name,variable=name)
        if alias not in entry['aliases']:entry['aliases'].append(alias)
        return TimedInput(bank,values.shape[0],1 if values.ndim==1 else values.shape[1],epsilon,k,values.ndim)
