"""Brian scheduling to native ordered dynamic actions (v5).

Conversion snapshots objects and emits SSA only; no Python simulation or VJP.
"""
import ast
import copy
import hashlib

import numpy as np
from brian2 import Synapses
from brian2.groups.group import CodeRunner
from brian2.groups.neurongroup import SubexpressionUpdater
from brian2.groups.subgroup import Subgroup
from brian2.core.variables import ArrayVariable
from brian2.core.functions import DEFAULT_FUNCTIONS, timestep
from brian2.core.clocks import Clock
from brian2.core.network import _check_multiple_summed_updaters
from brian2.codegen.translation import get_identifiers_recursively, make_statements
from brian2.equations.unitcheck import check_units_statements
from brian2.stateupdaters.base import StateUpdateMethod, UnsupportedEquationsException
from brian2.stateupdaters.exact import linear

from .training_inputs import TimedInputRegistry, TimedArray
from .protocol import canonical_bytes
from .training_brian import (TrainingConversionError, lower_brian_training,
                             _INTEGRATORS, _storage_indices, _state_dtype, _runtime_index, _endpoint_parent, _endpoint_start)
from .training_dynamic import compile_dynamic_transform, dynamic_action
from .training_queue import pending_events
from .training_brian_regular import prepare_regular, is_regular
from .training_equations import (SimulationTime, ClockTime, NormalNoise, UniformNoise,
                                 neuron_parameter_bank, typed_parameter, _DeferredParameter)


def _with_refractory_gate(program, guard):
    """Replace fixed-counter stage factors with a detached expression gate."""
    if not any(n['op']=='refractory_active' for n in program):return program
    nodes=copy.deepcopy(guard);gate=len(nodes)-1;remap={}
    for old,node in enumerate(program):
        if node['op']=='refractory_active':remap[old]=gate;continue
        value=dict(node);fields=['arg','left','right','low','high','condition','yes','no','slope','scale']
        if node['op'] in ('timed_parameter','parameter_gather','integer_parameter_gather'):
            fields+=['index']
            if node['op']=='timed_parameter':fields+=['time']
        for field in fields:
            if field in value:value[field]=remap[value[field]]
        nodes.append(value);remap[old]=len(nodes)-1
    return nodes[:remap[len(program)-1]+1]


def lower_brian_dynamic_training(network, *, input_group, layers,
                                 trainable_synapse_parameters=None,
                                 run_namespace=None, **options):
    """Snapshot clocked/event-driven synapses, pre/post paths and runtime weights.

    Synaptic ``w`` is trainable by default. Override with a mapping from Synapses
    names to lists of variables (an empty list freezes that object's parameters).
    An event-written variable is runtime state; training its initial value never
    overwrites carried state. Other selected constants remain optimizer slots.
    Values and equations use SI units. CPU supports local MPI; Metal/CUDA use
    the native v5 action ABI. Delayed paths and fixed/expression refractory are included.
    Standard synchronous run_regularly and constant-over-dt updaters keep Brian's
    scalar/vector separation, chronological schedule and typed cached state,
    including uniform/normal draws reused throughout a timestep.
    """
    def require(ok, code, owner, message):
        if not ok: raise TrainingConversionError(code, owner, message)
    layers=list(layers);groups=[input_group,*layers]
    require(not {'_defer_synapses','_input_registry','dynamic'}&options.keys(),'options',network,'reserved conversion option')
    input_registry=TimedInputRegistry()
    bundle=lower_brian_training(network,input_group=input_group,layers=layers,
                                run_namespace=run_namespace,_defer_synapses=True,_input_registry=input_registry,**options)
    plan=bundle.plan;weights=bundle.weights;provenance=bundle.provenance
    objects={o.name:o for o in [*layers,*network.sorted_objects]}
    constant_banks={id(objects[e['object']].variables[e['variable']]):e['bank'] for e in provenance.get('constant_sources',[])}
    namespace={} if run_namespace is None else dict(run_namespace)
    dt=float(input_group.clock.dt_);origin=float(input_group.clock.variables['t'].get_value()[0])
    require(np.isfinite(origin) and origin>=0 and all(float(g.clock.variables['t'].get_value()[0])==origin for g in layers),
            'clock',network,'dynamic layers must share the snapshot time')
    plan['clock']=dict(origin=origin,dt=dt)
    # Include even monitor/inactive-object clocks: Brian's Network._clocks does.
    # Equal dt clocks share a schedule because before_run aligns all to net.t.
    clock_dts=[dt]
    for obj in network.sorted_objects:
        clock=obj.clock
        require(type(clock) is Clock,'clock',obj,'dynamic conversion requires standard Brian clocks')
        value=float(clock.dt_)
        require(clock.epsilon_dt==Clock.epsilon_dt and np.isfinite(value) and value>0,
                'clock',obj,'dynamic conversion requires standard finite Brian clocks')
        if value not in clock_dts:clock_dts.append(value)
    require(len(clock_dts)<=256,'budget',network,'dynamic clock count exceeds 256')
    require(float(input_group.clock._calc_timestep(float(network.t)))*dt==origin,
            'clock',network,'snapshot clock differs from the next Network.run tick')
    clocks=dict(start=float(network.t),dts=clock_dts,epsilon=float(Clock.epsilon_dt))
    synapses=sorted((o for o in network.sorted_objects if isinstance(o,Synapses)),key=lambda s:s.name)
    regular_owners=[*layers,*synapses,*[o for o in network.sorted_objects
                    if isinstance(o,Subgroup) and _endpoint_parent(o,layers) is not None]]
    regular={}
    for obj in network.sorted_objects:
        if type(obj) not in (CodeRunner,SubexpressionUpdater):continue
        # This population supplies external spikes; its standard internal
        # updater is outside the trainable state graph, like its integrator.
        if (type(obj) is SubexpressionUpdater and obj.group==input_group
                and getattr(input_group,'subexpression_updater',None) is obj):continue
        require(is_regular(obj,regular_owners),'runner',obj,'regular runner requires a selected neuron, subgroup or Synapses owner')
        try:regular[obj.name]=prepare_regular(obj,namespace,dt,require)
        except TrainingConversionError:raise
        except Exception as error:raise TrainingConversionError('runner',obj,str(error)) from error
    regular_written={id(spec['variables'][name]) for spec in regular.values()
                     for name in spec['scalar_writes']|spec['vector_writes']}
    scheduled_noise_domains={obj.name:len(layers)+len(synapses)+len(regular)+k
        for k,obj in enumerate(sorted([obj for syn in synapses
                    for obj in [*syn._pathways,*syn.summed_updaters.values()]],key=lambda o:o.name))}
    requested={} if trainable_synapse_parameters is None else dict(trainable_synapse_parameters)
    require(set(requested)<=set(s.name for s in synapses),'parameter',network,'unknown trainable Synapses name')
    initial=list(bundle.initial_state);initial_parameters=[None]*len(initial);detached=[False]*len(initial)
    cells={};neuron_offsets={};voltage=[];offset=0;neuron=0
    for group,names in zip(layers,provenance['state_names']):
        neuron_offsets[group.name]=neuron
        for k,name in enumerate(names):cells[group.name,name]=list(range(offset+k*len(group),offset+(k+1)*len(group)))
        voltage.extend(cells[group.name,'v']);offset+=len(names)*len(group);neuron+=len(group)
    # The rectangular v4 prefix remains ABI-compatible, but each logical name
    # resolves to one canonical physical variable. Unused alias slots are inert.
    storage={};unused=[];linked_targets=set()
    for group in [*layers,*synapses]:
        equations=group.user_equations if group in layers else group.equations
        linked_targets.update(id(group.variables[e.varname]) for e in equations.values() if 'linked' in e.flags)
    for group,names in zip(layers,provenance['state_names']):
        for name in names:
            if name.startswith('__'):continue
            variable=group.variables[name]
            if 'linked' in group.user_equations[name].flags:continue
            own=cells[group.name,name]
            if variable.scalar:
                unused.extend(own[1:]);own=own[:1]
                cells[group.name,name]=own*len(group)
            storage[id(variable)]=own
    indirect_cells={};constant_index_tables={}
    def address(group,name,j,table=None,seen=()):
        nonlocal mapping_bytes
        require(name not in seen and len(seen)<16,'linked',group,'cyclic or excessive linked index depth')
        variable=group.variables[name]
        if table is None:
            require(id(variable) in storage,'linked',group,
                    f'{name} must link to mutable storage in a selected neuron layer or Synapses object')
            table=storage[id(variable)]
        index=group.variables.indices[name]
        if index in ('0','_idx'):
            k=0 if index=='0' else j
            require(k<len(table),'linked',group,f'invalid physical index for {name}')
            return table[k]
        mapping=group.variables[index]
        require(np.issubdtype(mapping.dtype,np.integer),'linked',group,'linked indices require integer storage')
        if mapping.constant:
            key=(id(mapping),id(table))
            if key not in constant_index_tables:
                values=np.asarray(mapping.get_value()).reshape(-1)
                require(np.all(values>=0) and np.all(values<len(table)),'linked',group,f'invalid physical indices for {name}')
                cost=len(values)*16+128;check_budget(cost);mapping_bytes+=cost
                constant_index_tables[key]=[table[int(k)] for k in values]
            return address(group,index,j,constant_index_tables[key],(*seen,name))
        require(_state_dtype(mapping)=='integer','linked',group,'runtime indices require int32 storage')
        source=address(group,index,j,seen=(*seen,name))
        if isinstance(source,int):return dict(index=source,tables=[table],root_name=index)
        return dict(source,tables=[*source['tables'],table])

    def linked_cells(group,name):
        nonlocal mapping_bytes
        out=[];row=[];indirect_cells[group.name,name]=row
        for j in range(len(group)):
            r=address(group,name,j)
            cost=16 if isinstance(r,int) else 128+sum(24+8*len(t) for t in r['tables'])
            check_budget(cost);mapping_bytes+=cost
            row.append(r if isinstance(r,dict) else None)
            if not isinstance(r,dict):out.append(r);continue
            if (group.name,name) in cells:index=cells[group.name,name][j]
            else:
                check_budget(64);index=len(initial);initial.append(0.)
                initial_parameters.append(None);detached.append(True);unused.append(index)
            dtype=_state_dtype(group.variables[name])
            if dtype=='integer':integer_states.add(index)
            elif dtype=='boolean':binary_states.append(index)
            out.append(index)
        return out
    for group,names in zip(layers,provenance['state_names']):
        for name in names:
            if name.startswith('__') or 'linked' not in group.user_equations[name].flags:continue
            unused.extend(cells[group.name,name])
    for index in unused:initial[index]=0.;detached[index]=True
    activity={};condition_storage={};neuron_condition_indices={};refractory_age={};refractory_lastspike={};refractory_words={}
    refractory_expressions=provenance.get('refractory_expressions',[None]*len(layers))
    for layer,group in enumerate(layers):
        spec=plan.get('refractory',[None]*len(layers))[layer]
        if spec is None:continue
        counters=cells[group.name,'__refractory_ticks']
        extra=len(group)*(5 if refractory_expressions[layer] is not None else 1)
        require(len(initial)+extra<=1_000_000 and (len(initial)+extra)*64+sum(len(w)*48 for w in weights)<=plan['max_tape_bytes'],
                'budget',group,'refractory control storage exceeds state budget')
        activity[group.name]=list(range(len(initial),len(initial)+len(group)))
        condition_storage[id(group.variables['not_refractory'])]=activity[group.name]
        initial.extend(np.asarray(group.variables['not_refractory'].get_value(),dtype=float).tolist());initial_parameters.extend([None]*len(group));detached.extend([True]*len(group))
        for index in counters:detached[index]=True
        if refractory_expressions[layer] is not None:
            last=np.asarray(group.variables['lastspike'].get_value(),dtype=float)
            require(np.all(np.isfinite(last)),'refractory',group,'lastspike must be finite')
            elapsed=np.asarray(timestep(origin-last,dt))
            require(np.all(elapsed>=0),'refractory',group,'lastspike must not be in the future')
            for table,values in ((refractory_age,np.minimum(elapsed,2**31-1)),(refractory_lastspike,last)):
                table[group.name]=list(range(len(initial),len(initial)+len(group)))
                initial.extend(values.astype(float).tolist());initial_parameters.extend([None]*len(group));detached.extend([True]*len(group))
            bits=last.astype(np.float64).view(np.uint64);refractory_words[group.name]=[]
            for word in (0,1):
                values=(bits>>(32*word)).astype(np.uint32).view(np.int32)
                indices=list(range(len(initial),len(initial)+len(group)));refractory_words[group.name].append(indices)
                initial.extend(values.astype(float).tolist());initial_parameters.extend([None]*len(group));detached.extend([True]*len(group))
        variables=group.resolve_all(group.equations.names|group.equations.identifiers|{'dt'},
                                    run_namespace=namespace,user_identifiers=set())
        update=_INTEGRATORS[group.state_updater.method_choice](group.equations,variables=variables)
        if refractory_expressions[layer] is not None:update=group.state_updater._get_refractory_code(namespace)+update
        indices={}
        for phase,code in [('update',update),('threshold',group.events['spike']),('reset',group.event_codes['spike'])]:
            index_name='not_refractory'
            for name in sorted(get_identifiers_recursively([code],group.variables)):
                condition=getattr(group.variables.get(name),'conditional_write',None)
                if condition is not None and condition.name=='not_refractory':index_name=name
            indices[phase]=index_name
        neuron_condition_indices[group.name]=indices
    programs=[];program_ids={};bindings=provenance['bindings'];syn_info={};summations=[]
    integer_states={k for row in refractory_age.values() for k in row}|{k for rows in refractory_words.values() for row in rows for k in row};binary_states=[k for row in activity.values() for k in row]
    integer_parameters=list(provenance.get('integer_parameters',[]))
    for group,names in zip(layers,provenance['state_names']):
        for name,dtype in zip(names,provenance['state_types'][layers.index(group)]):
            if dtype=='float' or 'linked' in group.user_equations[name].flags:continue
            indices=set(cells[group.name,name])
            if dtype=='integer':integer_states.update(indices)
            else:binary_states.extend(indices)
            for index in indices:detached[index]=True
    queue_layout={};delay_paths=[];action_bytes=0;program_bytes=0;restart_rules={};constant_indices={}
    mapping_bytes=sum(len(m['indices'])*16+128 for m in provenance.get('parameter_mappings',[]))
    def check_budget(extra=0):
        require(len(initial)<=1_000_000 and len(initial)*64+sum(len(w)*48 for w in weights)+action_bytes+program_bytes+mapping_bytes+extra<=plan['max_tape_bytes'],
                'budget',network,'dynamic state/actions exceed memory budget')
    class Actions(list):
        def append(self,action):
            nonlocal action_bytes
            require(len(self)<1_000_000,'budget',network,'dynamic action count exceeds budget')
            access=action.get('indirect',{})
            cost=256+len(action['reads'])*40+sum(128+sum(24+8*len(t) for t in r['tables'])
                for field in ('reads','writes') for r in access.get(field,{}).values())
            check_budget(cost)
            super().append(action);action_bytes+=cost
    actions=Actions()
    def context_slots(programs):
        return {node.get('index',0) for program in programs for node in program
                if node['op'] in ('voltage','state','integer_state','refractory_active')}

    def attach_indices(action,descriptors,output_slots,names):
        """Bind logical locals before writes; keep their Brian writeback order."""
        if not descriptors:return action
        used=context_slots(programs[action['program_set']])
        writes={}
        for output,slot in enumerate(output_slots):
            if slot not in descriptors:continue
            r=descriptors[slot];root=names.get(r['root_name'])
            if root is None:
                root=len(action['reads']);action['reads'].append(r['index'])
            if root in output_slots:index=dict(kind='output',slot=output_slots.index(root))
            else:index=dict(kind='read',slot=root);used.add(root)
            writes[str(output)]=dict(index=index,tables=r['tables'])
        reads={str(slot):dict(index=r['index'],tables=r['tables']) for slot,r in descriptors.items() if slot in used}
        require(len(action['reads'])<=64,'budget',network,'indexed context exceeds 64 slots')
        if reads or writes:action['indirect']=dict(reads=reads,writes=writes)
        return action

    def descriptors(group,names,j):
        return {slot:indirect_cells[group.name,name][j] for slot,name in enumerate(names)
                if (group.name,name) in indirect_cells and indirect_cells[group.name,name][j] is not None}

    def index_descriptor(group,name,j):
        row=indirect_cells.get((group.name,name))
        return None if row is None else row[j]

    def possible_writes(action):
        access=action.get('indirect',{}).get('writes',{})
        return {index for slot,fixed in enumerate(action['writes'])
                for index in (access[str(slot)]['tables'][-1] if str(slot) in access else [fixed])}

    def ordered_outputs(names,written,reads,indexed):
        ordered=[names[name] for name in sorted(written&names.keys())]
        if indexed:return ordered
        winners={reads[slot]:slot for slot in ordered if slot not in indexed}
        return [slot for slot in ordered if slot in indexed or winners[reads[slot]]==slot]
    try:_check_multiple_summed_updaters(network.sorted_objects)
    except Exception as error:raise TrainingConversionError('summed',network,str(error)) from error

    def program_set(value):
        nonlocal program_bytes
        key=canonical_bytes(value)
        if key not in program_ids:
            require(len(programs)<4096,'budget',network,'dynamic program set budget exceeded')
            cost=sum(len(program) for program in value)*128;check_budget(cost)
            program_ids[key]=len(programs);programs.append(value);program_bytes+=cost
        return program_ids[key]

    def parameter_bank(owner,name,values,trainable,kind):
        bank=len(weights);weights.append(values.tolist())
        plan['projections'].append(neuron_parameter_bank(len(values)))
        plan['masks'].append([1.]*len(values));plan['trainable'].append(trainable)
        bindings.append(dict(bank=bank,object=owner.name,variables=[name],kind=kind,trainable=trainable))
        return bank

    def input_bank(name,values):
        check_budget(values.size*48+128)
        require(len(weights)<256,'budget',network,'timed input bank count exceeded')
        # parameter_bank accepts Brian objects only for their stable names.
        from types import SimpleNamespace
        return parameter_bank(SimpleNamespace(name=name),'values',values.astype(float),False,'timed_input')

    parameter_references=provenance.pop('deferred_parameter_references',[])
    check_budget(128*len(parameter_references));mapping_bytes+=128*len(parameter_references)
    parameter_reference_ids={(r['object'],r['variable']):i for i,r in enumerate(parameter_references)}
    parameter_addresses={};bank_tables={};gather_tables={}

    def deferred_parameter(group,name):
        nonlocal mapping_bytes
        key=(group.name,name)
        if key not in parameter_reference_ids:
            check_budget(128);mapping_bytes+=128
            parameter_reference_ids[key]=len(parameter_references)
            parameter_references.append(dict(object=group.name,variable=name,bank=constant_banks[id(group.variables[name])]))
        return _DeferredParameter(constant_banks[id(group.variables[name])],parameter_reference_ids[key],_state_dtype(group.variables[name]))

    def resolve_parameters(source,j,reads,indexed):
        """Replace private references with reads of pre-statement selectors.

        Extra integer context slots always snapshot physical state. They never
        refer to an SSA local mutated earlier in the user's statement sequence.
        """
        nonlocal mapping_bytes
        slots={};out=[]
        for program in source:
            nodes=[];remap={}
            for old,node in enumerate(program):
                if node['op'] in ('_deferred_parameter','_deferred_integer_parameter'):
                    ref=node['reference'];entry=parameter_references[ref];bank=entry['bank']
                    key=(ref,j)
                    if bank not in bank_tables:
                        cost=len(weights[bank])*8+128;check_budget(cost);mapping_bytes+=cost
                        bank_tables[bank]=list(range(len(weights[bank])))
                    if key not in parameter_addresses:
                        group=objects[entry['object']]
                        resolved=address(group,entry['variable'],j,table=bank_tables[bank])
                        cost=16 if isinstance(resolved,int) else 128+sum(24+8*len(t) for t in resolved['tables'])
                        check_budget(cost);mapping_bytes+=cost;parameter_addresses[key]=resolved
                    r=parameter_addresses[key]
                    dtype='integer' if node['op']=='_deferred_integer_parameter' else 'float'
                    if isinstance(r,int):nodes.append(dict(op='integer_parameter' if dtype=='integer' else 'parameter',bank=bank,index=r))
                    else:
                        if ref not in slots:
                            slot=len(reads);reads.append(r['index']);slots[ref]=slot
                            if len(r['tables'])>1:indexed[slot]=dict(r,tables=r['tables'][:-1])
                        nodes.append(dict(op='integer_state',index=slots[ref]));selector=len(nodes)-1
                        table=r['tables'][-1]
                        if len(table)!=len(weights[bank]) or not all(k==i for i,k in enumerate(table)):
                            table_key=id(table)
                            if table_key not in gather_tables:
                                cost=len(table)*48+128;check_budget(cost)
                                require(len(weights)<256,'budget',network,'parameter routing bank count exceeded')
                                from types import SimpleNamespace
                                route=parameter_bank(SimpleNamespace(name=entry['object']),entry['variable'],np.asarray(table),False,'parameter_index_table')
                                integer_parameters.extend([route,k] for k in range(len(table)))
                                gather_tables[table_key]=route
                            nodes.append(dict(op='integer_parameter_gather',bank=gather_tables[table_key],index=selector));selector=len(nodes)-1
                        nodes.append(dict(op='integer_parameter_gather' if dtype=='integer' else 'parameter_gather',bank=bank,index=selector))
                else:
                    value=dict(node)
                    fields=['arg','left','right','low','high','condition','yes','no','slope','scale']
                    if node['op'] in ('timed_parameter','parameter_gather','integer_parameter_gather'):
                        fields+=['index']
                        if node['op']=='timed_parameter':fields+=['time']
                    for field in fields:
                        if field in value:value[field]=remap[value[field]]
                    nodes.append(value)
                remap[old]=len(nodes)-1
            require(len(nodes)<=128,'budget',network,'resolved parameter program exceeds 128 nodes')
            out.append(nodes)
        require(len(reads)<=64,'budget',network,'parameter gather context exceeds 64 slots')
        return out

    def constant_mapping(group,name):
        nonlocal mapping_bytes
        key=(group.name,name)
        if key not in constant_indices:
            cost=len(group)*16+128;check_budget(cost);mapping_bytes+=cost
            constant_indices[key]=dict(object=group.name,variable=name,bank=constant_banks[id(group.variables[name])])
            if _runtime_index(group,name):constant_indices[key]['runtime']=True
            else:constant_indices[key]['indices']=_storage_indices(group,name).tolist()
        return constant_indices[key]

    def constant_parameter(group,name,j):
        entry=constant_mapping(group,name)
        return deferred_parameter(group,name) if entry.get('runtime') else typed_parameter(entry['bank'],entry['indices'][j],_state_dtype(group.variables[name]))

    for domain,syn in enumerate(synapses,len(layers)):
        source_group=_endpoint_parent(syn.source,groups);target_group=_endpoint_parent(syn.target,layers)
        require(source_group is not None and target_group is not None,'endpoint',syn,'endpoints must belong to selected populations')
        require(len(syn)>0 or bool(syn.summed_updaters) or any(spec['group']==syn for spec in regular.values()),
                'topology',syn,'materialized connections, summed or regular updates are required')
        allowed=set(syn._pathways)|set(syn.summed_updaters.values())
        if syn.state_updater is not None:allowed.add(syn.state_updater)
        allowed.update(obj for obj in syn.contained_objects if obj.name in regular)
        require(set(syn.contained_objects)==allowed,'runner',syn,'additional synaptic runners are unsupported')
        eqs=syn.equations
        substitutions={name:ast.parse(expr.code,mode='eval').body for name,expr in eqs.get_substituted_expressions(include_subexpressions=True)
                       if name in eqs.subexpr_names}
        class Expand(ast.NodeTransformer):
            def visit_Name(self,node):
                return copy.deepcopy(substitutions[node.id]) if isinstance(node.ctx,ast.Load) and node.id in substitutions else node
        summed_codes={}
        for updater in syn.summed_updaters.values():
            summed_group=_endpoint_parent(updater.target,layers)
            require(updater.active and updater.when=='groups' and summed_group is not None,'summed',updater,
                    'summed updates require an active groups runner targeting a selected neuron layer')
            suffix='_pre' if updater.target_varname.endswith('_pre') else '_post'
            name=updater.target_varname[:-len(suffix)]
            require((summed_group.name,name) in cells and not updater.target_var.constant and not updater.target_var.scalar,
                    'summed',updater,'summed targets must be mutable per-neuron physical states')
            code=f'{updater.target_varname} += ({updater.expression.code})'
            try:
                resolved=dict(syn.variables);resolved.update(syn.resolve_all(updater.expression.identifiers,run_namespace=namespace))
                check_units_statements(code,resolved)
            except Exception as error:raise TrainingConversionError('units',updater,str(error)) from error
            summed_codes[updater.name]=ast.unparse(Expand().visit(ast.parse(code)))
            summations.append(dict(object=updater.name,synapses=syn.name,target=updater.target.name,variable=name,
                                   direction=suffix[1:],order=updater.order,expression=updater.expression.code))
        event_names=set() if syn.event_driven is None else set(syn.event_driven.diff_eq_names)
        mutable=set(eqs.diff_eq_names)|event_names|{name for name in eqs
                    if id(syn.variables[name]) in regular_written}
        path_codes={};path_delays={};path_pending={};path_runtime={}
        for path in syn._pathways:
            require(path.active and path.prepost in ('pre','post') and path.event=='spike' and path.when=='synapses',
                    'pathway',path,'only active spike pre/post pathways in the synapses slot are supported')
            require(float(path.clock.dt_)==dt,'clock',path,'event pathways require the network timestep')
            delays=np.asarray(path.delay[:],dtype=float).reshape(-1)
            require(len(delays) in (1,len(syn)) and np.all(np.isfinite(delays)) and np.all(delays>=0)
                    and np.all(delays/dt+.5<=1_000_000),'delay',path,'delays must be finite nonnegative values within the history budget')
            path_delays[path.name]=np.floor(np.broadcast_to(delays,(len(syn),))/dt+.5).astype(np.int64)
            try:path_pending[path.name]=pending_events(path.queue,dt,len(syn),max_bytes=plan['max_tape_bytes'])
            except Exception as error:raise TrainingConversionError('queue',path,str(error)) from error
            tree=ast.parse(path.code,mode='exec')
            for node in ast.walk(tree):
                if isinstance(node,ast.Name) and isinstance(node.ctx,ast.Store):
                    require(node.id=='delay' or node.id not in path.variables or node.id in syn.variables,
                            'pathway',path,f'event writes to pathway-owned storage {node.id} require runtime lowering')
                    if node.id=='delay':
                        require(not path.variables['delay'].scalar,'pathway',path,
                                'Brian event pathways cannot write scalar/shared delay storage')
                if isinstance(node,ast.Name) and isinstance(node.ctx,ast.Store) and node.id in syn.variables:
                    require(not syn.variables[node.id].scalar and syn.variables.indices[node.id]!='0',
                            'pathway',path,'Brian event pathways cannot write scalar/shared storage')
                    require(not syn.variables[node.id].constant,'pathway',path,
                            'event writes to constant parameters or fixed index storage require runtime lowering')
            mutable|={n.id for n in ast.walk(tree) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store) and n.id in eqs}
            try:
                ids={n.id for n in ast.walk(tree) if isinstance(n,ast.Name)}
                # Brian checks local temporaries with the same statement unit checker.
                resolved=dict(syn.variables);resolved['delay']=path.variables['delay']
                external=ids-set(resolved)-{n.id for n in ast.walk(tree) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store)}
                resolved.update(syn.resolve_all(external|set(eqs.identifiers),run_namespace=namespace))
                check_units_statements(path.code,resolved)
            except Exception as error:raise TrainingConversionError('units',path,str(error)) from error
            if 'delay' in ids:
                # Pathway storage is distinct for pre/post paths, even though
                # both use the same logical name in their source statements.
                require(len(initial)+len(syn)<=1_000_000,'budget',path,'pathway delay storage exceeds state budget')
                check_budget(len(syn)*64)
                values=(delays[:1] if path.variables['delay'].scalar and len(syn) else np.broadcast_to(delays,(len(syn),))).tolist()
                indices=list(range(len(initial),len(initial)+len(values)))
                initial.extend(values);initial_parameters.extend([None]*len(values));detached.extend([False]*len(values))
                restart_rules.update((index,dict(kind='initial')) for index in indices)
                path_runtime[path.name]={'delay':indices}
            # Materialize Brian's subexpression caches before replacing random
            # calls. Expanding a stochastic subexpression at each use would
            # accidentally turn one cached draw into several independent draws.
            try:
                scalar,vector=make_statements(path.code,resolved,np.float64,optimise=False)
                path_codes[path.name]='\n'.join(f'{s.var} {"=" if s.op==":=" else s.op} {s.expr}'
                                               for s in [*scalar,*vector])
            except Exception as error:raise TrainingConversionError('pathway',path,str(error)) from error
        if event_names:mutable.add('lastupdate')
        chosen=list(requested.get(syn.name,['w'] if 'w' in eqs and 'linked' not in eqs['w'].flags else []))
        declarations=(set(eqs)-eqs.subexpr_names)|event_names
        require(len(chosen)==len(set(chosen)) and set(chosen)<=declarations,'parameter',syn,'trainable names must be synaptic declarations')
        source=np.asarray(syn.variables['_synaptic_pre'].get_value(),dtype=int)
        target=np.asarray(syn.variables['_synaptic_post'].get_value(),dtype=int)
        require(len(syn)*256+len(initial)*64+sum(len(w)*48 for w in weights)<=plan['max_tape_bytes'],
                'budget',syn,'dynamic topology exceeds memory budget')
        runtime={};params={};aliases=set();constant_links=set()
        link_indices={syn.variables.indices[eq.varname] for eq in eqs.values() if 'linked' in eq.flags}
        for name in sorted(declarations|mutable):
            variable=syn.variables[name]
            if name in link_indices and variable.constant and np.issubdtype(variable.dtype,np.integer):
                require(name not in chosen,'parameter',syn,'linked index storage is not differentiable')
                continue
            if name in link_indices and not variable.constant:mutable.add(name)
            try:dtype=_state_dtype(variable)
            except ValueError as error:raise TrainingConversionError('state',syn,str(error)) from error
            require(name not in chosen or dtype=='float','parameter',syn,'trainable synaptic variables must be floating point')
            if name in eqs and 'linked' in eqs[name].flags:
                require(name not in chosen,'parameter',syn,'train the canonical source instead of a linked alias')
                if variable.constant:
                    constant_mapping(syn,name);constant_links.add(name)
                    continue
                aliases.add(name)
                continue
            if id(variable) in linked_targets and not variable.constant:mutable.add(name)
            values=np.asarray(variable.get_value(),dtype=float).reshape(-1)
            require(values.size==(1 if variable.scalar else len(syn)) and np.all(np.isfinite(values)),
                    'state',syn,f'invalid initial values for {name}')
            if id(variable) in constant_banks:
                bank=constant_banks[id(variable)];plan['trainable'][bank]=name in chosen
                next(binding for binding in bindings if binding['bank']==bank)['trainable']=name in chosen
            else:bank=parameter_bank(syn,name,values,True,'synapse_initial' if name in mutable else 'synapse_constant') if name in chosen and len(values) else None
            if name in mutable:
                require(name=='lastupdate' or not variable.constant,'state',syn,'constant synaptic variables cannot be written')
                indices=list(range(len(initial),len(initial)+len(values)));runtime[name]=indices
                storage[id(variable)]=indices
                restart=dict(kind='time',clock=clock_dts.index(float(syn.clock.dt_))) if name=='lastupdate' else dict(kind='initial')
                restart_rules.update((index,restart) for index in indices)
                initial.extend(values.tolist());detached.extend([name=='lastupdate' or dtype!='float']*len(values))
                if dtype=='integer':integer_states.update(indices)
                elif dtype=='boolean':binary_states.extend(indices)
                initial_parameters.extend([None if bank is None else [bank,i] for i in range(len(values))])
            else:params[name]=(values,bank)
        syn_info[syn.name]=dict(runtime=runtime,params=params,aliases=aliases,constant_links=constant_links,source=source,target=target,
            source_group=source_group,target_group=target_group,domain=domain)
        try:
            eqs.check_units(syn,run_namespace=namespace)
            if syn.event_driven is not None:syn.event_driven.check_units(syn,run_namespace=namespace)
        except Exception as error:raise TrainingConversionError('units',syn,str(error)) from error
        integrator_variables=dict(syn.variables)
        identifiers=set(eqs.identifiers)-set(eqs.stochastic_variables)
        if syn.event_driven is not None:identifiers.update(syn.event_driven.identifiers)
        try:integrator_variables.update(syn.resolve_all(identifiers,run_namespace=namespace))
        except Exception as error:raise TrainingConversionError('coefficient',syn,str(error)) from error
        continuous=''
        if eqs.diff_eq_names:
            require(float(syn.clock.dt_)==dt and float(syn.clock.variables['t'].get_value()[0])==origin,
                    'clock',syn,'continuous synapses require the network clock')
            method=syn.state_updater.method_choice
            methods=[method] if isinstance(method,str) else method
            require(isinstance(methods,(tuple,list)) and not syn.state_updater.method_options,
                    'integrator',syn,'select builtin synaptic integration methods without options')
            registry={**_INTEGRATORS,'exact':linear,'linear':linear}
            for method in methods:
                require(isinstance(method,str) and method in registry and StateUpdateMethod.stateupdaters.get(method) is registry[method],
                        'integrator',syn,'custom synaptic integrators are unsupported')
                try:continuous=registry[method](eqs,variables=integrator_variables);break
                except UnsupportedEquationsException:continue
            require(bool(continuous),'integrator',syn,'no selected integration method supports these equations')
        event_code=''
        if event_names:
            try:event_code=linear(syn.event_driven,variables=syn.variables)
            except Exception as error:raise TrainingConversionError('event-driven',syn,str(error)) from error
            class Elapsed(ast.NodeTransformer):
                def visit_Name(self,node):
                    return ast.parse('(t-lastupdate)',mode='eval').body if node.id=='dt' else node
            event_code=ast.unparse(Elapsed().visit(ast.parse(event_code)))
        syn_info[syn.name].update(continuous=continuous,event_code=event_code,path_codes=path_codes,summed_codes=summed_codes,
                                 path_delays=path_delays,path_pending=path_pending,path_runtime=path_runtime)

    # Resolve after every canonical source has been allocated: names and
    # network declaration order must not decide whether a cross-object link works.
    for group,names in zip(layers,provenance['state_names']):
        for name in names:
            if not name.startswith('__') and 'linked' in group.user_equations[name].flags:
                cells[group.name,name]=linked_cells(group,name)
    for syn in synapses:
        info=syn_info[syn.name]
        for name in sorted(info['aliases']):info['runtime'][name]=linked_cells(syn,name)

    def edge_mask(info,edge):
        if 'w' in info['aliases'] or 'w' in info['constant_links']:return None
        if 'w' in info['runtime']:
            ids=info['runtime']['w'];return initial_parameters[ids[0 if len(ids)==1 else edge]]
        if 'w' in info['params']:
            values,bank=info['params']['w']
            if bank is not None:return [bank,0 if len(values)==1 else edge]
        return None

    def build_synaptic(syn,edge,code,*,trigger=None,streams=(),owner=None,pathway=None,
                       noise_domain=None,event_noise=None):
        info=syn_info[syn.name];pre=int(info['source'][edge]);post=int(info['target'][edge])
        tree=ast.parse(code,mode='exec');used_names={n.id for n in ast.walk(tree) if isinstance(n,ast.Name)}
        written_names={n.id for n in ast.walk(tree) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store)}
        synaptic_dt=float(syn.clock.dt_)
        reads=[];names={};indexed={};parameters={'dt':synaptic_dt,'t':ClockTime(clock_dts.index(synaptic_dt)),
            't_pre':SimulationTime(),'t_post':SimulationTime(),
            'dt_pre':float(syn.source.clock.dt_),'dt_post':float(syn.target.clock.dt_)}
        def bind(name,index,descriptor=None):
            if name not in used_names and not name.startswith('_b2_guard_'):return
            # Brian Cython reads each logical name into a distinct local before
            # running the path. Autapse aliases can share physical storage but
            # must not observe each other's local assignments immediately.
            if name not in names:
                names[name]=len(reads);reads.append(index)
                if descriptor is not None:indexed[names[name]]=descriptor
        for name,indices in info['runtime'].items():
            descriptor=index_descriptor(syn,name,edge)
            bind(name,indices[0 if len(indices)==1 else edge],descriptor)
        for name,indices in info['path_runtime'].get(pathway,{}).items():bind(name,indices[0 if len(indices)==1 else edge])
        for group,j,suffix in [(info['source_group'],pre,'_pre'),(info['target_group'],post,'_post')]:
            if group is input_group:continue
            for name in provenance['state_names'][layers.index(group)]:
                descriptor=index_descriptor(group,name,j)
                if descriptor is not None:descriptor=dict(descriptor,root_name=descriptor['root_name']+suffix)
                if name+suffix in syn.variables:bind(name+suffix,cells[group.name,name][j],descriptor)
                if suffix=='_post' and name in syn.variables and name not in info['runtime'] and name not in info['params']:
                    bare=None if descriptor is None else dict(descriptor,root_name=descriptor['root_name'][:-len(suffix)])
                    bind(name,cells[group.name,name][j],bare)
        def bind_condition(name,variable,index_name):
            require(id(variable) in condition_storage,'refractory',syn,
                    'conditional writes require a selected standard refractory source')
            table=condition_storage[id(variable)]
            resolved=address(syn,index_name,edge,table=table)
            bind(name,resolved['tables'][-1][0] if isinstance(resolved,dict) else resolved,
                 resolved if isinstance(resolved,dict) else None)

        # Match create_runner_codeobj: resolve sorted identifiers, add condition
        # variables by name, then assign each condition's index from the last
        # referencing variable. Cython snapshots these flags before statements,
        # while writeback may use an integer local modified by those statements.
        referenced={name:syn.variables[name] for name in sorted(used_names) if name in syn.variables}
        conditions={};condition_indices={}
        for name,variable in referenced.items():
            condition=getattr(variable,'conditional_write',None)
            if condition is None:continue
            condition_indices[condition.name]=name
            if condition.name not in referenced or referenced[condition.name] is condition:
                conditions[condition.name]=condition
        resolved_conditions={**referenced,**conditions}
        # Include flags introduced by code generation: a user assignment to
        # that name becomes a physical condition write, not a local temporary.
        for name,variable in resolved_conditions.items():
            if name in used_names and id(variable) in condition_storage:
                bind_condition(name,resolved_conditions[name],condition_indices.get(name,name))
        guards={};mutable_guards=set()
        for name in sorted(written_names&names.keys()):
            variable=syn.variables.get(name)
            condition=getattr(variable,'conditional_write',None)
            if condition is None:continue
            guard=condition.name if condition.name in written_names and condition.name in names else f'_b2_guard_{condition.name}'
            if guard not in names:
                bind_condition(guard,resolved_conditions[condition.name],condition_indices[condition.name])
            guards[names[name]]=names[guard]
            if guard==condition.name:mutable_guards.add(names[guard])
        for name,(values,bank) in info['params'].items():
            index=0 if len(values)==1 else edge
            parameters[name]=(int(values[index]) if _state_dtype(syn.variables[name])=='integer' else bool(values[index]) if _state_dtype(syn.variables[name])=='boolean' else float(values[index])) if bank is None else typed_parameter(bank,index,_state_dtype(syn.variables[name]))
        for name in sorted(info['constant_links']):
            parameters[name]=constant_parameter(syn,name,edge)
        for k,name in enumerate(streams):parameters['__native_normal_'+name]=NormalNoise(k)
        class Draw(ast.NodeTransformer):
            def visit_Assign(self,node):
                if len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in streams:
                    name=node.targets[0].id
                    class Replace(ast.NodeTransformer):
                        def visit_Call(self,call):
                            require(isinstance(call.func,ast.Name) and call.func.id=='randn' and not call.args and not call.keywords,
                                    'noise',syn,'unexpected stochastic integrator draw')
                            return ast.Name(id='__native_normal_'+name,ctx=ast.Load())
                    node.value=Replace().visit(node.value)
                return node
        tree=Draw().visit(tree)
        explicit_streams=[]
        class ExplicitDraw(ast.NodeTransformer):
            def visit_Call(self,node):
                if isinstance(node.func,ast.Name) and node.func.id in ('rand','randn'):
                    require(not node.args and not node.keywords,'noise',syn,'random functions take no arguments')
                    resolved=syn.resolve_all({node.func.id},run_namespace=namespace)[node.func.id]
                    require(resolved is DEFAULT_FUNCTIONS[node.func.id],'function',syn,'custom random functions are unsupported')
                    index=len(streams)+len(explicit_streams)
                    require(index<16,'noise',syn,'synaptic code exceeds 16 random streams')
                    name='__native_explicit_random_'+str(index)
                    parameters[name]=(NormalNoise if node.func.id=='randn' else UniformNoise)(index)
                    explicit_streams.append(node.func.id)
                    return ast.Name(id=name,ctx=ast.Load())
                return self.generic_visit(node)
        tree=ExplicitDraw().visit(tree)
        locals_={n.id for n in ast.walk(tree) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store)}
        needed={n.id for n in ast.walk(tree) if isinstance(n,ast.Name)}-names.keys()-parameters.keys()-locals_
        # Non-scalar neuron constants retain any optimizer bindings from the base lowerer.
        for name in sorted(needed):
            try:variable=syn.resolve_all({name},run_namespace=namespace)[name]
            except Exception as error:raise TrainingConversionError('coefficient',syn,str(error)) from error
            if isinstance(variable,TimedArray):
                try:parameters[name]=input_registry.resolve(variable,syn,name,input_bank,max_values=plan['max_tape_bytes']//48)
                except ValueError as error:raise TrainingConversionError('input',syn,str(error)) from error
                continue
            if name in DEFAULT_FUNCTIONS:
                require(variable is DEFAULT_FUNCTIONS[name],'function',syn,'custom function replacements are unsupported');continue
            if name in ('i','j','N','N_pre','N_post'):
                parameters[name]=dict(i=pre-_endpoint_start(syn.source),j=post-_endpoint_start(syn.target),
                    N=len(syn),N_pre=len(syn.source),N_post=len(syn.target))[name];continue
            require(hasattr(variable,'get_value') and variable.constant,'coefficient',syn,f'{name} requires a runtime state input that is not available')
            if id(variable) in constant_banks:
                parameters[name]=constant_parameter(syn,name,edge);continue
            values=np.asarray(variable.get_value()).reshape(-1)
            require(values.size>0 and values.dtype.kind in 'fiub' and np.all(np.isfinite(values)),
                    'coefficient',syn,f'{name} must be a finite real constant')
            mapped=None;index=0;indexed_owner=False
            for group,j,suffix in [(info['source_group'],pre,'_pre'),(info['target_group'],post,'_post')]:
                original=name[:-len(suffix)] if name.endswith(suffix) else name
                if original in group.variables and variable is group.variables[original] and (name.endswith(suffix) or suffix=='_post'):
                    index=j;indexed_owner=True
                    for binding in bindings:
                        if binding['object']==group.name and original in binding['variables']:
                            mapped=(binding['bank'],j if binding['kind']=='neuron_array' else binding['variables'].index(original))
            require(variable.scalar or indexed_owner and len(values)>index,'coefficient',syn,f'{name} has an unsupported indexed shape')
            parameters[name]=typed_parameter(*mapped,_state_dtype(variable)) if mapped is not None else values[0 if variable.scalar else index].item()
        try:transform=compile_dynamic_transform(ast.unparse(tree),states=names,parameters=parameters,write_guards=guards,mutable_write_guards=mutable_guards,state_types={slot:'integer' if index in integer_states else 'boolean' if index in binary_states else 'float' for slot,index in enumerate(reads)})
        except (ValueError,RecursionError) as error:raise TrainingConversionError('expression',syn,str(error)) from error
        # Brian's Cython writeback is sorted by logical variable name. If two
        # names write one cell, retain the final write but preserve both locals
        # in every expression and accumulate all aliased read adjoints natively.
        if indexed:
            by_slot=dict(zip(transform['writes'],transform['programs']))
            outputs=[(slot,by_slot[slot]) for slot in ordered_outputs(names,locals_,reads,indexed)]
        else:
            winners={}
            for name in sorted(locals_&names.keys()):winners[reads[names[name]]]=names[name]
            outputs=[(slot,program) for slot,program in zip(transform['writes'],transform['programs']) if winners[reads[slot]]==slot]
        transform['writes']=[slot for slot,_ in outputs];transform['programs']=[program for _,program in outputs]
        transform['programs']=resolve_parameters(transform['programs'],edge,reads,indexed)
        transform['context_size']=len(reads)
        mask=edge_mask(info,edge)
        action=dynamic_action(transform,reads,owner=neuron_offsets[info['target_group'].name]+post if owner is None else owner,
                                      program_set=program_set(transform['programs']),trigger=trigger,
                                      parameter_index=edge,
                                      noise_domain=(noise_domain if noise_domain is not None else scheduled_noise_domains.get(pathway,info['domain'])) if explicit_streams else info['domain'],
                                      noise_entity=edge,noise_streams=len(streams)+len(explicit_streams),mask=mask)
        if pathway is not None and action['noise_streams']:
            require(event_noise is not None,'noise',syn,'event draws require a persistent emission identity')
            action['event_noise']=dict(event_noise)
        action=attach_indices(action,indexed,transform['writes'],names)
        if trigger is not None and trigger.get('state'):
            # Delay graph rebuilding removes this private trailing gate. Resolve
            # parameter gathers and indirect write roots before appending it so
            # no model context can accidentally be removed in its place.
            require(len(action['reads'])<64,'budget',syn,'delayed context exceeds 64 slots')
            action['reads'].append(trigger['index'])
        actions.append(action)
        return actions[-1]

    regular_layout={}

    def build_regular(spec,domain):
        runner=spec['runner'];group=spec['group'];variables=spec['variables']
        parent=_endpoint_parent(group,layers)
        info=syn_info.get(group.name)
        owner=(neuron_offsets[parent.name]+_endpoint_start(group) if parent is not None
               else neuron_offsets[info['target_group'].name])

        def allocate(dtype):
            check_budget(64);index=len(initial)
            initial.append(0.);initial_parameters.append(None);detached.append(dtype!='float')
            if dtype=='integer':integer_states.add(index)
            if dtype=='boolean':binary_states.append(index)
            return index

        def statement_type(statement):
            dtype=np.dtype(statement.dtype)
            require(dtype.kind in 'fb' or dtype==np.dtype('int32'),'state',runner,
                    'regular temporaries require float, Boolean or int32 storage')
            return 'float' if dtype.kind=='f' else 'boolean' if dtype.kind=='b' else 'integer'

        scalar_names=spec['scalar_arrays']|{s.var for s in spec['scalar']}
        types={name:_state_dtype(variables[name]) for name in spec['scalar_arrays']}
        types.update({s.var:statement_type(s) for s in spec['scalar']})
        scratch={name:allocate(types[name]) for name in sorted(scalar_names)}
        # Vector temporaries also receive typed cells, so integer overflow and
        # Boolean assignments follow the same coercions as physical storage.
        temporary={}
        for statement in spec['vector']:
            name=statement.var
            if not isinstance(variables.get(name),ArrayVariable) and name not in scratch and name not in temporary:
                temporary[name]=allocate(statement_type(statement))
                # Masked synaptic actions own their vector-local scratch too.
                # Every declaration overwrites it, but structural migration
                # still needs an explicit restart rule for all masked writes.
                restart_rules[temporary[name]]=dict(kind='initial')
        regular_layout[runner.name]=dict(scalar=scratch,temporary=temporary,noise_domain=domain,
                                         when=runner.when,order=runner.order)

        def resolve(name,j):
            variable=variables[name]
            if name in DEFAULT_FUNCTIONS:
                require(variable is DEFAULT_FUNCTIONS[name],'function',runner,'custom function replacements are unsupported')
                return None,None
            if isinstance(variable,TimedArray):
                return None,input_registry.resolve(variable,group,name,input_bank,max_values=plan['max_tape_bytes']//48)
            if id(variable) in condition_storage:
                index=spec['indices'][name]
                reference=next((key for key in variables if key in group.variables and
                                group.variables.indices[key]==index),None)
                require(reference is not None,'refractory',runner,'unresolved regular condition index')
                return address(group,reference,j,table=condition_storage[id(variable)]),None
            if id(variable) in storage:return address(group,name,j),None
            if name in ('t','dt'):
                value=float(group.clock.dt_)
                return None,ClockTime(clock_dts.index(value)) if name=='t' else value
            if name in ('t_pre','t_post','dt_pre','dt_post') and info is not None:
                endpoint=group.source if name.endswith('_pre') else group.target
                value=float(endpoint.clock.dt_)
                return None,ClockTime(clock_dts.index(value)) if name.startswith('t_') else value
            if id(variable) in constant_banks:return None,constant_parameter(group,name,j)
            for binding in bindings:
                if binding['kind'] not in ('neuron','neuron_array'):continue
                source=objects[binding['object']]
                for k,key in enumerate(binding['variables']):
                    if source.variables.get(key) is not variable:continue
                    if binding['kind']=='neuron':return None,typed_parameter(binding['bank'],k,_state_dtype(variable))
                    constant_banks[id(variable)]=binding['bank']
                    return None,constant_parameter(group,name,j)
            for syn in synapses:
                for key,(values,bank) in syn_info[syn.name]['params'].items():
                    if variable is syn.variables[key]:
                        table=list(range(len(values)))
                        r=address(group,name,j,table=table)
                        require(isinstance(r,int),'linked',runner,'runtime-indexed regular constants require a canonical parameter bank')
                        return None,values[r].item() if bank is None else typed_parameter(bank,r,_state_dtype(variable))
            require(hasattr(variable,'get_value') and variable.constant,'coefficient',runner,
                    f'{name} requires runtime storage in a selected object')
            values=np.asarray(variable.get_value()).reshape(-1)
            require(values.size>0 and values.dtype.kind in 'fiub' and np.all(np.isfinite(values)),
                    'coefficient',runner,'regular constants must be finite real values')
            if variable.scalar:return None,values[0].item()
            r=address(group,name,j,table=list(range(len(values))))
            require(isinstance(r,int),'linked',runner,'runtime-indexed constants require a canonical parameter bank')
            return None,values[r].item()

        def emit(code,j,local,*,destinations=None,writeback=False,stream_offset=0,vector=False):
            tree=ast.parse(code);used={n.id for n in ast.walk(tree) if isinstance(n,ast.Name)}
            written={n.id for n in ast.walk(tree) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store)}
            guards={name:flag for name,flag in spec['guards'].items() if name in written and not writeback}
            used.update(guards.values())
            reads=[];names={};indexed={};parameters={};dtypes={}
            for name in sorted(used):
                if name in local:r=local[name];parameter=None
                elif name in variables:r,parameter=resolve(name,j)
                else:continue
                if r is None:
                    if parameter is not None:parameters[name]=parameter
                    continue
                slot=len(reads);names[name]=slot
                index=r['tables'][-1][0] if isinstance(r,dict) else r
                reads.append(index)
                if isinstance(r,dict):indexed[slot]=r
                dtypes[slot]='integer' if index in integer_states else 'boolean' if index in binary_states else 'float'
            # Calls are replaced before SSA composition, making repeated uses
            # of a local share its draw and distinct calls use distinct streams.
            streams=[];draws=[]
            class Draw(ast.NodeTransformer):
                def visit_Call(self,node):
                    if isinstance(node.func,ast.Name) and node.func.id in ('randn','rand'):
                        require(not node.args and not node.keywords,'noise',runner,'random functions take no arguments')
                        draws.append(dict(kind=node.func.id,stream=stream_offset+len(streams)))
                        name='__regular_normal_'+str(len(streams));parameters[name]=(NormalNoise if node.func.id=='randn' else UniformNoise)(stream_offset+len(streams));streams.append(name)
                        return ast.Name(id=name,ctx=ast.Load())
                    return self.generic_visit(node)
            tree=Draw().visit(tree)
            if type(runner) is SubexpressionUpdater and j==0 and draws:
                regular_layout[runner.name].setdefault('draws',{})['vector' if vector else 'scalar']=draws
            require(stream_offset+len(streams)<=16,'noise',runner,'regular runner exceeds 16 random call sites')
            guard_slots={names[name]:names[flag] for name,flag in guards.items()}
            mutable={names[flag] for flag in guards.values() if flag in written}
            try:
                transform=compile_dynamic_transform(ast.unparse(tree),states=names,parameters=parameters,
                    write_guards=guard_slots,mutable_write_guards=mutable,state_types=dtypes)
            except (ValueError,RecursionError) as error:raise TrainingConversionError('expression',runner,str(error)) from error
            by_slot=dict(zip(transform['writes'],transform['programs']))
            output=ordered_outputs(names,written,reads,indexed)
            transform['writes']=output;transform['programs']=[by_slot[slot] for slot in output]
            transform['programs']=resolve_parameters(transform['programs'],j,reads,indexed)
            transform['context_size']=len(reads)
            entity_owner=owner+j if parent is not None else owner+(int(info['target'][j]) if len(group) else 0)
            action=dynamic_action(transform,reads,owner=owner if destinations is not None or writeback else entity_owner,
                program_set=program_set(transform['programs']),parameter_index=j,
                noise_domain=domain,noise_entity=j,noise_streams=stream_offset+len(streams) if streams else 0,
                mask=edge_mask(info,j) if vector and info is not None else None)
            action=attach_indices(action,indexed,output,names)
            if destinations is not None:
                action['writes']=[destinations[name] for name in sorted(written&names.keys())
                                  if names[name] in output]
                require(len(action['writes'])==len(output),'runner',runner,'invalid regular scalar snapshot')
                action['reads'].extend(index for index in action['writes'] if index not in action['reads'])
                require(len(action['reads'])<=64,'budget',runner,'regular writeback exceeds context budget')
                if 'indirect' in action:action['indirect'].pop('writes',None)
            actions.append(action)

        # All scalar array reads happen before scalar assignments. Each alias
        # has its own scratch cell, including aliases of the same shared array.
        if spec['scalar_arrays']:
            copies={f'__regular_snapshot_{k}':scratch[name]
                    for k,name in enumerate(sorted(spec['scalar_arrays']))}
            emit('\n'.join(f'__regular_snapshot_{k} = {name}'
                           for k,name in enumerate(sorted(spec['scalar_arrays']))),0,copies,writeback=True)
        def source(statements):
            return '\n'.join(f'{s.var} {"=" if s.op==":=" else s.op} {s.expr}' for s in statements)
        if spec['scalar']:emit(source(spec['scalar']),0,scratch)
        # Sorted Cython array writeback, leaving all scalar locals intact for
        # the vector loop even when several names alias one physical cell.
        if spec['scalar_writes']:
            destinations={name:resolve(name,0)[0] for name in sorted(spec['scalar_writes'])}
            require(all(isinstance(index,int) for index in destinations.values()),'linked',runner,
                    'scalar regular writes require fixed physical addresses')
            winners={index:name for name,index in destinations.items()}
            selected={name:index for name,index in destinations.items() if winners[index]==name}
            emit('\n'.join(name+' = '+name for name in selected),0,scratch,destinations=selected,writeback=True)
        if spec['vector']:
            offset=sum(isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in ('randn','rand')
                       for node in ast.walk(ast.parse(source(spec['scalar']))))
            for j in range(len(group)):emit(source(spec['vector']),j,{**scratch,**temporary},stream_offset=offset,vector=True)

    def history(length, pending=False):
        require(length<=1_000_000-len(initial),'budget',network,'delay history exceeds state budget')
        check_budget(length*64)
        indices=list(range(len(initial),len(initial)+length))
        initial.extend([0.]*(length-1)+[float(pending)])
        initial_parameters.extend([None]*length);detached.extend([False]*length);binary_states.extend(indices)
        restart_rules.update((index,dict(kind='queue')) for index in indices)
        return indices

    def advance_history(indices,owner,mask,trigger):
        # Shift in ascending chunks: each chunk's final source has not yet been
        # overwritten. 63 writes plus its next source fit the 64-slot context.
        for start in range(0,len(indices)-1,63):
            reads=indices[start:min(start+64,len(indices))]
            ps=program_set([[dict(op='state',index=k)] for k in range(1,len(reads))])
            actions.append(dict(owner=owner,mask=mask,reads=reads,writes=reads[:-1],program_set=ps,threshold=None,trigger=None))
        last=indices[-1]
        actions.append(dict(owner=owner,mask=mask,reads=[last],writes=[last],program_set=program_set([[dict(op='constant',value=0.)]]),threshold=None,trigger=None))
        if trigger is not None:
            actions.append(dict(owner=owner,mask=mask,reads=[last],writes=[last],program_set=program_set([[dict(op='constant',value=1.)]]),threshold=None,trigger=trigger))

    # Linked shared storage retains every referencing object's lifetime even
    # when it is only read. A one-cell identity action makes that explicit in
    # the same action graph audited by native migration (and has identity VJP).
    for syn in synapses:
        info=syn_info[syn.name]
        for name,indices in info['runtime'].items():
            candidates=set(indices)
            for r in indirect_cells.get((syn.name,name),[]):
                if r is not None:candidates.update(r['tables'][-1])
            if not any(index in restart_rules for index in candidates) or id(syn.variables[name]) not in linked_targets:continue
            for edge in range(len(syn)):
                r=index_descriptor(syn,name,edge)
                targets=r['tables'][-1] if r is not None else [indices[0 if len(indices)==1 else edge]]
                for index in sorted(set(targets)):
                    ps=program_set([[dict(op='integer_state' if index in integer_states else 'state',index=0)]])
                    actions.append(dict(owner=neuron_offsets[info['target_group'].name]+int(info['target'][edge]),
                        reads=[index],writes=[index],program_set=ps,threshold=None,trigger=None,mask=edge_mask(info,edge)))
    for group,names in zip(layers,provenance['state_names']):
        for name in names:
            for j,index in enumerate(cells[group.name,name]):
                r=index_descriptor(group,name,j)
                for target in sorted(set(r['tables'][-1] if r is not None else [index])):
                    if target not in restart_rules:continue
                    actions.append(dict(owner=neuron_offsets[group.name]+j,reads=[target],writes=[target],
                        program_set=program_set([[dict(op='integer_state' if target in integer_states else 'state',index=0)]]),threshold=None,trigger=None))

    def append_refractory_context(group,j,phase,reads,indexed):
        r=address(group,neuron_condition_indices[group.name][phase],j,table=activity[group.name])
        slot=len(reads);reads.append(r['tables'][-1][0] if isinstance(r,dict) else r)
        if isinstance(r,dict):indexed[slot]=r
        reads.extend([refractory_age[group.name][j],refractory_lastspike[group.name][j],*[row[j] for row in refractory_words[group.name]]])

    for obj in network.sorted_objects:
        if obj.name in regular:
            build_regular(regular[obj.name],len(layers)+len(synapses)+list(regular).index(obj.name))
            continue
        handled=False
        for layer,group in enumerate(layers):
            if obj is group.state_updater or obj is group.resetter['spike']:
                reset=obj is group.resetter['spike'];key='state_resets' if reset else 'state_equations'
                state_names=provenance['state_names'][layer];code=copy.deepcopy(plan[key][layer])
                spec=plan.get('refractory',[None]*len(layers))[layer]
                expression_ref=refractory_expressions[layer]
                if spec is not None:
                    counter=len(state_names)-1
                    if reset:code[counter]=[dict(op='constant',value=float(max(spec['steps']-1,0)))]
                    else:
                        for s in spec['clamp']:
                            nodes=code[s];result=len(nodes)-1;gate=len(nodes);old=gate+1
                            nodes.extend([dict(op='refractory_active',index=counter),dict(op='state',index=s),dict(op='select',condition=gate,yes=result,no=old)])
                        code[counter]=[dict(op='state',index=counter),dict(op='constant',value=1.),dict(op='sub',left=0,right=1),
                                       dict(op='constant',value=0.),dict(op='max',left=2,right=3)]
                        code.append([dict(op='refractory_active',index=counter)])
                        if expression_ref is not None:
                            code=[_with_refractory_gate(p,expression_ref['program']) for p in code]
                            # Elapsed ticks are for the next tick, unless this
                            # tick's threshold overwrites them with one.
                            code.append([dict(op='integer_state',index=len(state_names)+1),
                                         dict(op='integer_constant',value=2**31-2),
                                         dict(op='integer_binary',kind='min',left=0,right=1),
                                         dict(op='integer_constant',value=1),
                                         dict(op='integer_binary',kind='add',left=2,right=3)])
                written=({n.id for n in ast.walk(ast.parse(group.event_codes['spike']))
                          if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store)} if reset else set(group.equations.diff_eq_names))
                if spec is not None:written.add('__refractory_ticks')
                for j in range(len(group)):
                    reads=[cells[group.name,name][j] for name in state_names];owner=neuron_offsets[group.name]+j
                    indexed=descriptors(group,state_names,j);names={name:s for s,name in enumerate(state_names)}
                    needed={names[name] for name in written&names.keys()}
                    needed.update(context_slots([code[s] for s in needed]))
                    if expression_ref is not None and not reset:needed.update(context_slots([expression_ref['program']]))
                    indexed={s:r for s,r in indexed.items() if s in needed}
                    if expression_ref is not None:
                        append_refractory_context(group,j,'reset' if reset else 'update',reads,indexed)
                    elif spec is not None and not reset:
                        # Brian assigns the freshly computed flag through the
                        # final conditional variable's index, even for a read.
                        r=address(group,neuron_condition_indices[group.name]['update'],j,table=activity[group.name])
                        reads.append(r['tables'][-1][0] if isinstance(r,dict) else r)
                        if isinstance(r,dict):indexed[len(state_names)]=r
                    outputs=ordered_outputs(names,written,reads,indexed)
                    if not indexed:outputs.sort()
                    if spec is not None and not reset:outputs.append(len(state_names))
                    if expression_ref is not None and not reset:outputs.append(len(state_names)+1)
                    if not outputs:continue
                    ps=program_set(resolve_parameters([code[s] for s in outputs],j,reads,indexed))
                    action=dict(owner=owner,reads=reads,writes=[reads[s] for s in outputs],program_set=ps,threshold=None,
                        trigger=dict(external=False,index=owner) if reset else None,detach_trigger=plan['detach_reset'] if reset else False,
                        parameter_index=j,noise_domain=layer,noise_entity=j,noise_streams=len(provenance['noise_names'][layer]) if not reset or provenance['neuron_draws'][layer]['reset'] else 0)
                    actions.append(attach_indices(action,indexed,outputs,names))
                handled=True;break
            if obj is group.thresholder['spike']:
                for j in range(len(group)):
                    owner=neuron_offsets[group.name]+j
                    margin=provenance['threshold_margins'][layer]
                    if margin is not None:
                        check_budget(64);index=len(initial);initial.append(0.);initial_parameters.append(None);detached.append(False)
                        state_names=provenance['state_names'][layer];indexed=descriptors(group,state_names,j)
                        context=[cells[group.name,name][j] for name in state_names]
                        if refractory_expressions[layer] is not None:append_refractory_context(group,j,'threshold',context,indexed)
                        context.append(index);output_slot=len(context)-1
                        resolved=resolve_parameters([margin['program']],j,context,indexed)
                        action=dict(owner=owner,reads=context,writes=[index],program_set=program_set(resolved),
                            threshold=None,trigger=None,parameter_index=j,noise_domain=layer,noise_entity=j,
                            noise_streams=len(provenance['noise_names'][layer]) if provenance['neuron_draws'][layer]['threshold'] else 0)
                        actions.append(attach_indices(action,indexed,[output_slot],
                                                      {name:s for s,name in enumerate(state_names)}))
                        provenance.setdefault('threshold_margin_layout',{}).setdefault(group.name,[]).append(index)
                        reads=[index]
                    else:reads=[cells[group.name,'v'][j]]
                    if group.name in activity:
                        r=address(group,neuron_condition_indices[group.name]['threshold'],j,table=activity[group.name])
                        if isinstance(r,dict):
                            check_budget(64);gate=len(initial);initial.append(0.);initial_parameters.append(None);detached.append(True);binary_states.append(gate)
                            actions.append(dict(owner=owner,reads=[r['tables'][-1][0],gate],writes=[gate],
                                program_set=program_set([[dict(op='state',index=0)]]),threshold=None,trigger=None,
                                indirect=dict(reads={'0':dict(index=r['index'],tables=r['tables'])},writes={})))
                        else:gate=r
                        reads.append(gate)
                    actions.append(dict(owner=owner,reads=reads,writes=[],program_set=None,threshold=owner,trigger=None,
                        threshold_margin=margin is not None,threshold_inclusive=margin is not None and margin['inclusive'],
                        threshold_predicate=margin is not None and margin.get('predicate',False)))
                    if group.name in activity:
                        gate=activity[group.name][j]
                        actions.append(dict(owner=owner,reads=[gate],writes=[gate],program_set=program_set([[dict(op='constant',value=0.)]]),
                                            threshold=None,trigger=dict(external=False,index=owner),detach_trigger=True))
                        if refractory_expressions[layer] is not None:
                            controls=[refractory_age[group.name][j],refractory_lastspike[group.name][j],*[row[j] for row in refractory_words[group.name]]]
                            actions.append(dict(owner=owner,reads=controls,writes=controls,
                                program_set=program_set([[dict(op='integer_constant',value=1)],[dict(op='time')],
                                    *[[dict(op='time_word',word=word,float32=np.dtype(group.variables['lastspike'].dtype)==np.dtype('float32'))] for word in (0,1)]]),
                                threshold=None,trigger=dict(external=False,index=owner),detach_trigger=True))
                handled=True;break
        if handled:continue
        for syn in synapses:
            info=syn_info[syn.name]
            if obj.name in info['summed_codes']:
                pre=obj.target_varname.endswith('_pre');name=obj.target_varname[:-4 if pre else -5]
                # Cython clears exactly the target view, then adds in edge order.
                group=_endpoint_parent(obj.target,layers);start=_endpoint_start(obj.target)
                ps=program_set([[dict(op='integer_constant',value=0)]]) if _state_dtype(obj.target_var)=='integer' else program_set([[dict(op='constant',value=0.)]])
                for j in range(start,start+len(obj.target)):
                    index=cells[group.name,name][j]
                    actions.append(dict(owner=neuron_offsets[group.name]+j,reads=[index],writes=[index],
                                        program_set=ps,threshold=None,trigger=None))
                indices=info['source'] if pre else info['target']
                for edge in range(len(syn)):
                    build_synaptic(syn,edge,info['summed_codes'][obj.name],owner=neuron_offsets[group.name]+int(indices[edge]),
                                   noise_domain=scheduled_noise_domains[obj.name])
            if obj is syn.state_updater and info['continuous']:
                require(obj.active and obj.when=='groups','schedule',obj,'continuous synaptic updates must run in groups')
                for edge in range(len(syn)):build_synaptic(syn,edge,info['continuous'],streams=sorted(syn.equations.stochastic_variables))
            if any(obj is path for path in syn._pathways):
                pre=obj.prepost=='pre';source=info['source_group'] if pre else info['target_group']
                indices=info['source'] if pre else info['target']
                code=info['event_code']+'\n'+info['path_codes'][obj.name]
                if info['event_code']:code+='\nlastupdate=t'
                histories=[];layout=dict(pending=[],new=[]);queue_layout[obj.name]=layout
                delay_path=dict(name=obj.name,start=len(actions),end=0,pending=[],edges=[None]*len(syn))
                if obj.name in info['path_runtime'] and obj.variables['delay'].scalar:delay_path['shared_delay']=True
                # Events already queued at conversion precede every newly
                # emitted event in an arrival bin. Preserve all duplicates and
                # original entry order, including after a dt/delay change.
                for remaining,row in enumerate(info['path_pending'][obj.name]):
                    for edge in row:
                        fifo=history(remaining+1,pending=True)
                        action=build_synaptic(syn,edge,code,trigger=dict(external=False,state=True,index=fifo[0]),pathway=obj.name,
                                              event_noise=dict(delay=0,pending=len(delay_path['pending'])+1))
                        delay_path['pending'].append(dict(edge=edge,event=len(actions)-1,states=fifo))
                        histories.append((fifo,action['owner'],action['mask'],None))
                        layout['pending'].append(dict(edge=edge,remaining=remaining,states=fifo))
                delays=info['path_delays'][obj.name]
                for edge in sorted(range(len(syn)),key=lambda e:(-int(delays[e]),int(indices[e]),e)):
                    trigger=dict(external=source is input_group,index=int(indices[edge])+(0 if source is input_group else neuron_offsets[source.name]))
                    fifo=history(int(delays[edge])) if delays[edge] else []
                    action=build_synaptic(syn,edge,code,trigger=dict(external=False,state=True,index=fifo[0]) if fifo else trigger,pathway=obj.name,
                                          event_noise=dict(delay=int(delays[edge])))
                    delay_path['edges'][edge]=dict(event=len(actions)-1,source=trigger,states=fifo)
                    if obj.name in info['path_runtime']:
                        delay_cells=info['path_runtime'][obj.name]['delay']
                        delay_path['edges'][edge]['delay_state']=delay_cells[0 if len(delay_cells)==1 else edge]
                    if fifo:histories.append((fifo,action['owner'],action['mask'],trigger))
                    layout['new'].append(dict(edge=edge,delay=int(delays[edge]),states=fifo))
                for item in histories:advance_history(*item)
                delay_path['end']=len(actions);delay_paths.append(delay_path)
    controlled=sorted({tuple(a['mask']) for a in actions if a.get('mask') is not None})
    owned={};migration_bytes=len(controlled)*32
    check_budget(migration_bytes)
    def register(index,mask,restart):
        nonlocal migration_bytes
        if mask is None:return
        mask=tuple(mask);entry=owned.get(index)
        if entry is not None and mask in entry['owners']:return
        cost=16+(64 if entry is None else 0);check_budget(migration_bytes+cost);migration_bytes+=cost
        if entry is None:entry=owned[index]=dict(owners=set(),restart=restart)
        require(entry['restart']==restart,'migration',network,'inconsistent shared-state restart rules')
        entry['owners'].add(mask)
    pinned={index for action in actions if action.get('mask') is None for index in possible_writes(action)}
    for action in actions:
        for index in possible_writes(action):
            if index in restart_rules and index not in pinned:register(index,action.get('mask'),restart_rules[index])
    migration=dict(controlled_masks=[list(mask) for mask in controlled],cells=[dict(index=index,
        owners=[list(mask) for mask in sorted(entry['owners'])],restart=entry['restart']) for index,entry in sorted(owned.items())])
    # v5 executes the ordered action programs. Its retained v4 prefix declares
    # rectangular state shape; action-specific extra selector slots cannot be
    # represented there. Never serialize private unresolved nodes as executable IR.
    placeholders=[]
    for key in ('state_equations','state_resets'):
        for layer,row in enumerate(plan[key]):
            for slot,program in enumerate(row):
                if refractory_expressions[layer] is not None or any(n['op'].startswith('_deferred_') for n in program):
                    row[slot]=[dict(op='integer_state' if provenance['state_types'][layer][slot]=='integer' else 'state',index=slot)]
                    placeholders.append(dict(field=key,layer=layer,state=slot))
    if placeholders:provenance['v4_shape_placeholders']=placeholders
    plan.update(schema='b2-dynamic-training-plan-v5',dynamic=dict(migration=migration,clocks=clocks,binary_states=sorted(set(binary_states)),integer_states=sorted(integer_states),integer_parameters=integer_parameters,initial=initial,initial_parameters=initial_parameters,
        detached=detached,voltage=voltage,program_sets=programs,actions=list(actions)))
    plan['dynamic']['delay_layout']=dict(paths=delay_paths,free_cells=[])
    check_budget(sum(256+len(p['name'])+sum(96+len(e['states'])*16 for e in p['edges'])+
                     sum(80+len(e['states'])*16 for e in p['pending']) for p in delay_paths))
    if provenance.get('constant_sources'):
        maps=provenance.get('parameter_mappings',[])
        plan['dynamic']['parameter_maps']=[m['indices'] for m in maps]
        refs=[]
        for l,group in enumerate(layers):
            mapping=provenance['threshold_mappings'][l];ref=plan['threshold_parameters'][l]
            for j in range(len(group)):
                refs.append(None if ref is None else [ref[0],maps[mapping]['indices'][j] if mapping is not None else
                    ref[1]+(j if plan.get('threshold_per_neuron',[False]*len(layers))[l] else 0)])
        plan['dynamic']['threshold_references']=refs
        provenance['synaptic_constant_mappings']=list(constant_indices.values())
    if any(a.get('noise_streams',0) for a in actions):plan['noise_streams']=[len(n) for n in provenance['noise_names']]
    provenance['runtime_parameter_layout']=[dict(**entry,addresses={str(j):r for (ref,j),r in parameter_addresses.items() if ref==i})
                                            for i,entry in enumerate(parameter_references)]
    provenance.update(scope='ordered-dynamic-delayed-synapses',dynamic_state_layout={name:info['runtime'] for name,info in syn_info.items()},
        neuron_state_layout={group.name:{name:cells[group.name,name] for name in names}
                             for group,names in zip(layers,provenance['state_names'])},
        inactive_alias_slots=sorted(unused),storage_semantics='canonical-physical-variable-runtime-index-aliases' if any(any(r is not None for r in row) for row in indirect_cells.values()) else 'canonical-physical-variable-fixed-index-aliases',
        runtime_index_layout={group:{name:row for (owner,name),row in indirect_cells.items() if owner==group and any(r is not None for r in row)}
                              for group in sorted({owner for (owner,_),row in indirect_cells.items() if any(r is not None for r in row)})},
        state_layout='canonical-physical-with-rectangular-neuron-prefix',
        delay_queues=queue_layout,delay_semantics='brian-half-up-ticks-pending-prefix-then-emission-order',
        pathway_state_layout={path:states for info in syn_info.values() for path,states in info['path_runtime'].items()},
        synaptic_noise_domains={name:info['domain'] for name,info in syn_info.items()},
        scheduled_noise_domains=scheduled_noise_domains,
        pathway_alias_semantics='brian-cython-distinct-locals-sorted-writeback',
        conditional_write_semantics='brian-cython-shared-condition-name-last-referenced-index',
        refractory_activity_layout=activity,refractory_condition_indices=neuron_condition_indices,
        refractory_age_layout=refractory_age,refractory_lastspike_layout=refractory_lastspike,
        refractory_timestamp_words=refractory_words,
        refractory_expression_semantics='hard-detached-gate-current-duration-int32-next-tick-age' if refractory_age else None,
        regular_runner_layout=regular_layout,
        regular_semantics='scalar-snapshot-and-sorted-writeback-then-vector-loop',
        summed_updates=summations,summed_semantics='clear-target-then-original-edge-order-cython',
        clock_semantics='brian-network-min-clock-coalescing-f64-detached',
        event_gradient='one-hard-event-gate-per-composed-path-with-surrogate-vjp',timestamp_gradient='stop-gradient')
    provenance.pop('snapshot_sha256',None)
    bundle.initial_state=list(initial)
    provenance['snapshot_sha256']=hashlib.sha256(canonical_bytes(dict(plan=plan,weights=weights,initial=bundle.initial_membrane,
        initial_state=bundle.initial_state,provenance=provenance))).hexdigest()
    return bundle
