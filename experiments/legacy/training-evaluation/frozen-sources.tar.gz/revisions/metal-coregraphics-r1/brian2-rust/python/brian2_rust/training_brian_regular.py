"""Validate scheduled Brian assignments and retain their scalar/vector blocks."""
import copy

import numpy as np
from brian2.codegen.translation import analyse_identifiers, make_statements
from brian2.groups.group import CodeRunner
from brian2.groups.neurongroup import SubexpressionUpdater
from brian2.groups.subgroup import Subgroup
from brian2.equations.unitcheck import check_units_statements


def is_regular(obj, owners):
    return (type(obj) is CodeRunner or type(obj) is SubexpressionUpdater
            and getattr(obj.group, 'subexpression_updater', None) is obj) and any(obj.group == owner for owner in owners)


def regular_children(group, synapses):
    """Containers inserted by Group.run_on_clock are not extra execution."""
    return {obj for obj in group.contained_objects
            if is_regular(obj, [group]) or obj in synapses or
            isinstance(obj, Subgroup) and obj.source == group and
            all(is_regular(child, [obj]) for child in obj.contained_objects)}


def prepare_regular(runner, namespace, dt, require):
    from brian2.codegen.generators.cython_generator import CythonCodeGenerator
    from brian2.codegen.runtime.cython_rt import CythonCodeObject
    require(type(runner) in (CodeRunner, SubexpressionUpdater) and runner.template == 'stateupdate'
            and not runner.template_kwds and not runner.needed_variables
            and not runner.override_conditional_write
            and not hasattr(runner, 'variables')
            and 'update_abstract_code' not in runner.__dict__,
            'runner', runner, 'only standard run_regularly or constant-over-dt stateupdate runners are supported')
    require(runner.active, 'inactive', runner, 'inactive runners must be removed explicitly')
    require(float(runner.clock.dt_) == dt, 'clock', runner,
            'scheduled assignments currently require the network timestep')
    require(isinstance(runner.abstract_code, str) and len(runner.abstract_code) <= 16384,
            'budget', runner, 'regular source exceeds statement budget')
    group = runner.group
    _, known, unknown = analyse_identifiers(runner.abstract_code, group.variables, recursive=True)
    variables = group.resolve_all(sorted(known | unknown), run_namespace=namespace)
    conditions = {}
    for variable in variables.values():
        flag = getattr(variable, 'conditional_write', None)
        if flag is not None and (flag.name not in variables or variables[flag.name] is flag):
            conditions[flag.name] = flag
    variables.update(conditions)
    check_units_statements(runner.abstract_code, variables)
    indices = copy.copy(group.variables.indices)
    for name, variable in variables.items():
        flag = getattr(variable, 'conditional_write', None)
        if flag is not None:
            indices[flag.name] = indices[name]
    # Index dependencies are needed by the array helpers but not resolve_all.
    for name in list(variables):
        index = indices[name]
        seen = set()
        while index not in ('0', '_idx') and index not in seen:
            seen.add(index)
            variables[index] = group.variables[index]
            index = indices[index]
    scalar, vector = make_statements(runner.abstract_code, variables, np.float64, optimise=False)
    generator = CythonCodeGenerator(variables, indices, runner, {'_idx'}, CythonCodeObject,
                                    runner.name, 'stateupdate', allows_scalar_write=True)
    sr, sw, si, guards = generator.arrays_helper(scalar)
    vr, vw, vi, _ = generator.arrays_helper(vector)
    for name in list(vr):
        if variables[name].scalar and name not in vw:
            sr.add(name)
            vr.remove(name)
    require(all(not variables[name].read_only and not variables[name].constant
                for name in sw | vw), 'runner', runner, 'regular writes require mutable variables')
    return dict(runner=runner, group=group, variables=variables, indices=indices,
                scalar=scalar, vector=vector, scalar_arrays=sr | sw,
                scalar_writes=sw, vector_writes=vw, guards=guards)
