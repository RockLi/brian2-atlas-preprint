#include <metal_stdlib>
using namespace metal;
// One sample per GPU lane, batch-private VJPs; no atomic floating-point sum.
// This correctness-first kernel makes no performance/scalability claim.
kernel void atlas_lif_bptt(
 device const ulong* m [[buffer(0)]], device const float* p [[buffer(1)]],
 device const float* x [[buffer(2)]], device const float* w [[buffer(3)]],
 device const float* initial [[buffer(4)]], device const ulong* labels [[buffer(5)]],
 device float* pre [[buffer(6)]], device float* spike [[buffer(7)]],
 device float* membrane [[buffer(8)]], device float* grad [[buffer(9)]],
 device float* initial_grad [[buffer(10)]], device float* logits [[buffer(11)]],
 device float* losses [[buffer(12)]], device float* carry [[buffer(13)]],
 device float* ds [[buffer(14)]], device float* previous [[buffer(15)]], uint b [[thread_position_in_grid]]) {
 ulong B=m[0],T=m[1],L=m[2],I=m[3],N=m[4],E=m[5],C=m[16+L];
 if(b>=B)return;
 ulong base=ulong(b)*N;
 for(ulong k=0;k<N;k++){membrane[base+k]=initial[base+k];carry[base+k]=0;}
 for(ulong e=0;e<E;e++)grad[ulong(b)*E+e]=0;
 for(ulong t=0;t<T;t++){
  ulong at=(ulong(b)*T+t)*N;
  for(ulong l=0;l<L;l++)for(ulong j=0;j<m[17+l];j++){
   ulong k=m[40+l]+j;float u=p[l]*membrane[base+k];float s=float(u>p[L+l]);
   pre[at+k]=u;spike[at+k]=s;
   membrane[base+k]=m[6]?u:u-p[L+l]*s;
  }
  for(ulong l=0;l<L;l++)for(ulong j=0;j<m[17+l];j++){
   ulong k=m[40+l]+j;
   for(ulong i=0;i<m[16+l];i++){
    float input=l?spike[at+m[39+l]+i]:x[(ulong(b)*T+t)*I+i];
    membrane[base+k]+=w[m[64+l]+i*m[17+l]+j]*input;
   }
  }
  if(m[6])for(ulong k=0;k<N;k++)membrane[base+k]*=1-spike[at+k];
 }
 float scale=p[2*L+2];
 for(ulong j=0;j<C;j++){
  float sum=0;for(ulong t=0;t<T;t++)sum+=spike[(ulong(b)*T+t)*N+m[39+L]+j]*scale/float(T);
  logits[ulong(b)*C+j]=sum;
 }
 float maxlog=-INFINITY;for(ulong j=0;j<C;j++)maxlog=max(maxlog,logits[ulong(b)*C+j]);
 float denom=0;for(ulong j=0;j<C;j++)denom+=exp(logits[ulong(b)*C+j]-maxlog);
 losses[b]=maxlog+log(denom)-logits[ulong(b)*C+labels[b]];
 if(m[9])for(ulong t=T;t-->0;){
  ulong at=(ulong(b)*T+t)*N;
  for(ulong k=0;k<N;k++){ds[base+k]=0;previous[base+k]=0;}
  for(ulong j=0;j<C;j++){
   float d=(exp(logits[ulong(b)*C+j]-maxlog)/denom-float(j==labels[b]))/float(B);
   ds[base+m[39+L]+j]=d*scale/float(T);
  }
  for(ulong l=L;l-->0;){
   for(ulong i=0;i<m[16+l];i++)for(ulong j=0;j<m[17+l];j++){
    ulong k=m[40+l]+j,e=m[64+l]+i*m[17+l]+j;
    float g=carry[base+k]*(m[6]?1-spike[at+k]:1);
    float input=l?spike[at+m[39+l]+i]:x[(ulong(b)*T+t)*I+i];
    grad[ulong(b)*E+e]+=g*input;
    if(l)ds[base+m[39+l]+i]+=g*w[e];
   }
   for(ulong j=0;j<m[17+l];j++){
    ulong k=m[40+l]+j;float u=pre[at+k],s=spike[at+k];
    float q=1+p[2*L]*abs(u-p[L+l]);float phi=p[2*L+1]/(q*q);
    float before_reset=u;
    if(m[6]&&!m[7])for(ulong i=0;i<m[16+l];i++){
     float input=l?spike[at+m[39+l]+i]:x[(ulong(b)*T+t)*I+i];
     before_reset+=w[m[64+l]+i*m[17+l]+j]*input;
    }
    float derivative=m[6]?(1-s-(m[7]?0:before_reset*phi)):(1-(m[7]?0:p[L+l]*phi));
    previous[base+k]=p[l]*(carry[base+k]*derivative+ds[base+k]*phi);
   }
  }
  for(ulong k=0;k<N;k++)carry[base+k]=(t>0&&t%m[8]==0)?0:previous[base+k];
 }
 for(ulong k=0;k<N;k++)initial_grad[base+k]=carry[base+k];
}

// Bounded scalar SSA interpreter and reverse-mode VJP; all arithmetic executes
// on the selected GPU. Parameter nodes accumulate into the shared bank slots.
float atlas_equation(device const ulong* m,device const float* p,
 device const float* w,ulong layer,float voltage,device float* grad,
 ulong gradient_base,float seed,bool backward) {
 ulong header=m[11]+3*layer,count=m[header],start=m[header+1],constants=m[header+2];
 float value[128],adjoint[128];
 for(ulong i=0;i<count;i++){
  ulong q=start+4*i,op=m[q],a=m[q+1],b=m[q+2],param=m[q+3];float c=p[constants+i],z=0;
  switch(op){
   case 0:z=voltage;break;case 1:z=c;break;case 2:z=w[param];break;
   case 3:z=value[a]+value[b];break;case 4:z=value[a]-value[b];break;
   case 5:z=value[a]*value[b];break;case 6:z=value[a]/value[b];break;
   case 7:z=-value[a];break;case 8:z=exp(value[a]);break;case 9:z=log(value[a]);break;
   case 10:z=tanh(value[a]);break;case 11:z=sqrt(value[a]);break;
   case 12:z=sin(value[a]);break;case 13:z=cos(value[a]);break;
   case 14:z=c==0?1:pow(abs(value[a]),c);if(value[a]<0){if(floor(c)!=c)return NAN;if(fmod(abs(c),2.0f)==1)z=-z;}break;
  }
  if(!isfinite(z))return NAN;value[i]=z;adjoint[i]=0;
 }
 if(!backward)return value[count-1];
 adjoint[count-1]=seed;float dv=0;
 for(ulong i=count;i-->0;){
  ulong q=start+4*i,op=m[q],a=m[q+1],b=m[q+2],param=m[q+3];float c=p[constants+i],g=adjoint[i];
  if(!isfinite(g))return NAN;if(g==0)continue;
  switch(op){
   case 0:dv+=g;break;case 1:break;case 2:grad[gradient_base+param]+=g;break;
   case 3:adjoint[a]+=g;adjoint[b]+=g;break;case 4:adjoint[a]+=g;adjoint[b]-=g;break;
   case 5:adjoint[a]+=g*value[b];adjoint[b]+=g*value[a];break;
   case 6:adjoint[a]+=g/value[b];adjoint[b]-=g*value[a]/(value[b]*value[b]);break;
   case 7:adjoint[a]-=g;break;case 8:adjoint[a]+=g*value[i];break;
   case 9:adjoint[a]+=g/value[a];break;case 10:adjoint[a]+=g*(1-value[i]*value[i]);break;
   case 11:adjoint[a]+=g/(2*value[i]);break;case 12:adjoint[a]+=g*cos(value[a]);break;
   case 13:adjoint[a]-=g*sin(value[a]);break;
   case 14:if(c!=0){float z=pow(abs(value[a]),c-1);if(value[a]<0&&fmod(abs(c-1),2.0f)==1)z=-z;adjoint[a]+=g*c*z;}break;
  }
 }
 return dv;
}

// v2: explicit ordered projection graph with tied parameter indices. Thresholds
// precede all edges; every edge VJP precedes every neuron VJP, including cycles.
kernel void atlas_graph_bptt(
 device const ulong* m [[buffer(0)]], device const float* p [[buffer(1)]],
 device const float* x [[buffer(2)]], device const float* w [[buffer(3)]],
 device const float* initial [[buffer(4)]], device const ulong* labels [[buffer(5)]],
 device float* pre [[buffer(6)]], device float* spike [[buffer(7)]],
 device float* membrane [[buffer(8)]], device float* grad [[buffer(9)]],
 device float* initial_grad [[buffer(10)]], device float* logits [[buffer(11)]],
 device float* losses [[buffer(12)]], device float* carry [[buffer(13)]],
 device float* ds [[buffer(14)]], device float* previous [[buffer(15)]], uint b [[thread_position_in_grid]]) {
 ulong B=m[0],T=m[1],L=m[2],I=m[3],N=m[4],E=m[5],C=m[16+L],G=m[10];
 if(b>=B)return;
 ulong base=ulong(b)*N,cells=B*T*N;
 for(ulong k=0;k<N;k++){membrane[base+k]=initial[base+k];carry[base+k]=0;}
 for(ulong e=0;e<E;e++)grad[ulong(b)*E+e]=0;
 for(ulong t=0;t<T;t++){
  ulong at=(ulong(b)*T+t)*N;
  for(ulong l=0;l<L;l++)for(ulong j=0;j<m[17+l];j++){
   ulong k=m[40+l]+j;
   if(m[11])pre[2*cells+at+k]=membrane[base+k];
   float u=m[11]?atlas_equation(m,p,w,l,membrane[base+k],grad,ulong(b)*E,0,false):p[l]*membrane[base+k];
   ulong threshold_id=m[14]?m[m[14]+l]:0;float theta=threshold_id?w[threshold_id-1]:p[L+l];
   float s=float(u>theta);
   pre[at+k]=u;spike[at+k]=s;membrane[base+k]=m[6]?u:u-theta*s;
  }
  for(ulong e=0;e<G;e++){
   ulong q=84+4*e,source=m[q+1],target=m[q+2],param=m[q+3];
   float input=m[q]?x[(ulong(b)*T+t)*I+source]:spike[at+source];
   membrane[base+target]+=w[param]*input;
  }
  for(ulong k=0;k<N;k++){
   pre[cells+at+k]=membrane[base+k];
   if(m[6])membrane[base+k]*=1-spike[at+k];
  }
 }
 float scale=p[2*L+2];
 for(ulong j=0;j<C;j++){
  float sum=0;for(ulong t=0;t<T;t++)sum+=spike[(ulong(b)*T+t)*N+m[39+L]+j]*scale/float(T);
  logits[ulong(b)*C+j]=sum;
 }
 float maxlog=-INFINITY;for(ulong j=0;j<C;j++)maxlog=max(maxlog,logits[ulong(b)*C+j]);
 float denom=0;for(ulong j=0;j<C;j++)denom+=exp(logits[ulong(b)*C+j]-maxlog);
 losses[b]=maxlog+log(denom)-logits[ulong(b)*C+labels[b]];
 if(m[9])for(ulong t=T;t-->0;){
  ulong at=(ulong(b)*T+t)*N;
  for(ulong k=0;k<N;k++){ds[base+k]=0;previous[base+k]=0;}
  for(ulong j=0;j<C;j++){
   float d=(exp(logits[ulong(b)*C+j]-maxlog)/denom-float(j==labels[b]))/float(B);
   ds[base+m[39+L]+j]=d*scale/float(T);
  }
  for(ulong e=0;e<G;e++){
   ulong q=84+4*e,source=m[q+1],target=m[q+2],param=m[q+3];
   float g=carry[base+target]*(m[6]?1-spike[at+target]:1);
   float input=m[q]?x[(ulong(b)*T+t)*I+source]:spike[at+source];
   grad[ulong(b)*E+param]+=g*input;
   if(!m[q])ds[base+source]+=g*w[param];
  }
  for(ulong l=0;l<L;l++)for(ulong j=0;j<m[17+l];j++){
   ulong k=m[40+l]+j;float u=pre[at+k],s=spike[at+k];
   ulong threshold_id=m[14]?m[m[14]+l]:0;float theta=threshold_id?w[threshold_id-1]:p[L+l];
   float q=1+p[2*L]*abs(u-theta),phi=p[2*L+1]/(q*q);
   float derivative=m[6]?(1-s-(m[7]?0:pre[cells+at+k]*phi)):(1-(m[7]?0:theta*phi));
   if(threshold_id){
    float reset_theta=m[6]?(m[7]?0:pre[cells+at+k]*phi):(-s+(m[7]?0:theta*phi));
    grad[ulong(b)*E+threshold_id-1]+=carry[base+k]*reset_theta-ds[base+k]*phi;
   }
   float du=carry[base+k]*derivative+ds[base+k]*phi;
   previous[base+k]=m[11]?atlas_equation(m,p,w,l,pre[2*cells+at+k],grad,ulong(b)*E,du,true):p[l]*du;
  }
  for(ulong k=0;k<N;k++)carry[base+k]=(t>0&&t%m[8]==0)?0:previous[base+k];
 }
 for(ulong k=0;k<N;k++)initial_grad[base+k]=carry[base+k];
}
